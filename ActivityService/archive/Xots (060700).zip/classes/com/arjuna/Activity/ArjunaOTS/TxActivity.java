/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity.ArjunaOTS;

import com.arjuna.Activity.*;
import com.arjuna.Activity.ActivityCoordinator.*;
import com.arjuna.CosTransactions.ArjunaOTS.TxAssociation;
import org.omg.CosActivity.*;
import org.omg.CosTransactions.Control;

import org.omg.CORBA.SystemException;
import org.omg.CORBA.BAD_OPERATION;

/*
 * This is specific to the Arjuna transaction service and is a 
 * way of getting transactions to register themselves with activities
 * when they are created, and removed when they are terminated. If
 * the Arjuna OTS isn't being used then something else will have to be
 * substituted for this.
 */

public class TxActivity implements TxAssociation
{
    /*
     * Should throw system exceptions - am using an older version of
     * JTSArjuna.
     */

public void begin (Control tx)  // throws SystemException
    {
	if (tx != null)
	{	
	    try
	    {
		modifyActivity(tx, true);
	    }
	    catch (SystemException e)
	    {
	    }
	}
    }
    
public void commit (Control tx)  // throws SystemException
    {
	if (tx != null)
	{	
	    try
	    {
		modifyActivity(tx, false);
	    }
	    catch (SystemException e)
	    {
	    }
	}
    }

public void rollback (Control tx)  // throws SystemException
    {
	if (tx != null)
	{	
	    try
	    {
		modifyActivity(tx, false);
	    }
	    catch (SystemException e)
	    {
	    }
	}
    }
	
public void suspend (Control tx)  // throws SystemException
    {
    }
    
public void resume (Control tx)  // throws SystemException
    {
    }

public String name ()
    {
	return "TxActivity";
    }

private void modifyActivity (Control tx, boolean add) throws SystemException
    {
	try
        {
	    org.omg.CosActivity.Current current = CosActivity.get_current();

	    if (current != null)
	    {
		ActivityCoordinator act = current.get_coordinator();
		
		if (act != null)
		{
		    ActivityCoordinatorImple aw = ActivityCoordinatorImple.getActivityCoordinatorImple(act);

		    if (aw == null)
			throw new BAD_OPERATION("No such activity coordinator!");
		    else
		    {
			if (add)
			    aw.addTransaction(tx);
			else
			    aw.removeTransaction(tx);
		    }
		}
	    }
	}
	catch (Exception e)
	{
	    throw new BAD_OPERATION(e.toString());
	}
    }
    
};
