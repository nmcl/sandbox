/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity;

import com.arjuna.OrbCommon.ORBInterface;
import com.arjuna.CosTransactions.OTS;
import com.arjuna.CosTransactions.OTS_Current;
import org.omg.CosTransactions.*;
import org.omg.CosActivity.*;
import org.omg.CORBA.*;
import java.util.*;

import org.omg.CORBA.BAD_OPERATION;
import org.omg.CORBA.BAD_PARAM;
import org.omg.CORBA.UNKNOWN;
import org.omg.CORBA.SystemException;

class ActivityHierarchy
{

static final ActivityIdentity getId (Coordinator coord) throws SystemException 
    {
	if (coord == null)
	    throw new BAD_PARAM();
	
	try
	{
	    PropagationContext ctx = coord.get_txcontext();
	    ActivityIdentity id = new ActivityIdentity();
		    
	    id.type = 1;
	    id.timeout = ctx.timeout;
	    id.coord = null;
	    id.ctxId = new byte[ctx.currentTransaction.otid.tid.length];
		    
	    for (int i = 0; i < ctx.currentTransaction.otid.tid.length; i++)
		id.ctxId[i] = ctx.currentTransaction.otid.tid[i];
		    
	    id.pgCtx = null;
	    id.implementation_specific_data = ORBInterface.orb().create_any();

	    return id;
	}
	catch (Exception e)
	{
	    throw new BAD_OPERATION(e.toString());
	}
    }
    
static final ActivityIdentity getId (Control tx) throws SystemException
    {
	if (tx == null)
	    throw new BAD_PARAM();
	
	try
	{
	    Coordinator coord = tx.get_coordinator();

	    return ActivityHierarchy.getId(coord);
	}
	catch (Exception e)
	{
	    throw new BAD_OPERATION(e.toString());
	}
    }

static final ActivityIdentity getId (ActivityCoordinatorWrapper aw) throws SystemException
    {
	if (aw == null)
	    throw new BAD_PARAM();
	
	try
	{
	    ActivityIdentity id = new ActivityIdentity();
	
	    id.type = 2;
	    id.timeout = aw.get_timeout();
	    id.coord = aw.get_coordinator();
	    id.ctxId = id.coord.get_global_id();
	    id.pgCtx = null;
	    id.implementation_specific_data = ORBInterface.orb().create_any();

	    return id;
	}
	catch (Exception e)
	{
	    throw new BAD_OPERATION(e.toString());
	}	    
    }

static final ActivityContext getContext (Control tx) throws SystemException
    {
	if (tx == null)
	    throw new BAD_PARAM();
	else
	{
	    ActivityContext ctx = new ActivityContext();
	    
	    ctx.hierarchy = new ActivityIdentity[1];
	    ctx.hierarchy[0] = ActivityHierarchy.getId(tx);
	    ctx.implementation_specific_data = ORBInterface.orb().create_any();

	    return ctx;
	}
    }

static final ActivityContext getContext (Control tx,
					 ActivityCoordinatorWrapper aw,
					 boolean entireHierarchy) throws SystemException
    {
	if ((tx == null) || (aw == null))
	    throw new BAD_PARAM();
	else
	{
	    ActivityContext ctx1 = ActivityHierarchy.getContext(aw, entireHierarchy);
	    ActivityContext ctx2 = ActivityHierarchy.getContext(tx);
	    ActivityContext ctx3 = new ActivityContext();
	    
	    ctx3.implementation_specific_data = ORBInterface.orb().create_any();
	    ctx3.hierarchy = new ActivityIdentity[ctx1.hierarchy.length+ctx2.hierarchy.length];
	    
	    for (int i = 0; i < ctx1.hierarchy.length; i++)
		ctx3.hierarchy[i] = ctx1.hierarchy[i];
	    
	    for (int j = 0; j < ctx2.hierarchy.length; j++)
		ctx3.hierarchy[j+ctx1.hierarchy.length] = ctx2.hierarchy[j];
	    
	    return ctx3;
	}
    }

static final ActivityContext getContext (ActivityCoordinatorWrapper aw,
					 boolean entireContext) throws SystemException
    {
	if (aw == null)
	    throw new BAD_PARAM();
	else
	{
	    Vector tempCtx = new Vector();
	    int index = -1;
	    PropagationContext pgCtx = null;
	    boolean finished = false;	    

	    /*
	     * First any enclosed transactions.
	     *
	     * Remember, the first element in the context is the current
	     * "context", which can be either an activity, or a transaction!
	     */

	    try
	    {
		if (OTS.current().get_status() == org.omg.CosTransactions.Status.StatusActive)
		{
		    Control tx = OTS.current().get_control();

		    tempCtx.addElement(ActivityHierarchy.getId(tx));
		    
		    /*
		     * Now add all parent transactions until we get to the
		     * current activity.
		     */

		    pgCtx = tx.get_coordinator().get_txcontext();
		    
		    for (index = 0; (index < pgCtx.parents.length) && !finished; index++)
		    {
			if (ActivityHierarchy.isContainedBy(pgCtx.parents[index].coord, aw))
			    tempCtx.addElement(ActivityHierarchy.getId(pgCtx.parents[index].coord));
			else
			    finished = true;
		    }
		}
	    }
	    catch (Exception e)
	    {
		throw new BAD_OPERATION(e.toString());
	    }

	    /*
	     * Index should point to the start of the context contained by
	     * another activity.
	     */

	    ActivityCoordinatorWrapper coord = aw;

	    /*
	     * Now the activity.
	     */

	    while (aw != null)
	    {
		/*
		 * First the activity.
		 */

		tempCtx.addElement(ActivityHierarchy.getId(aw));

		/*
		 * Now any active enclosed transactions.
		 */

		if (index != -1)
		{
		    finished = false;
		    
		    for (; (index < pgCtx.parents.length) && !finished; index++)
		    {
			if (ActivityHierarchy.isContainedBy(pgCtx.parents[index].coord, aw))
			    tempCtx.addElement(ActivityHierarchy.getId(pgCtx.parents[index].coord));
			else
			    finished = true;
		    }
		}

		if (entireContext)
		    aw = aw.getParentCoordinator();
		else
		    aw = null;
	    }

	    ActivityContext ctx = new ActivityContext();
	    
	    ctx.hierarchy = new ActivityIdentity[tempCtx.size()];
	    
	    for (int i = 0; i < tempCtx.size(); i++)
		ctx.hierarchy[i] = (ActivityIdentity) tempCtx.elementAt(i);

	    ctx.implementation_specific_data = ORBInterface.orb().create_any();

	    return ctx;
	}
    }
	

    /*
     * Heavy-weight way of doing things. But since the OTS does not have
     * a "get-parent" operation we have to do something like this!
     */

private static final boolean isContainedBy (Coordinator coord,
					    ActivityCoordinatorWrapper aw) throws SystemException
    {
	Vector tx = aw.getEnclosedTransactions();
	
	if (tx == null)
	    return false;
	else
	{
	    for (int i = 0; i < tx.size(); i++)
	    {
		Control cont = (Control) tx.elementAt(i);
		
		if (cont != null)
		{
		    try
		    {
			Coordinator txCoord = cont.get_coordinator();
		    
			if (txCoord.is_same_transaction(coord))
			    return true;
		    }
		    catch (Unavailable e)
		    {
			return false; // ??!!
		    }
		}
	    }
	}

	return false;
    }
    
};
