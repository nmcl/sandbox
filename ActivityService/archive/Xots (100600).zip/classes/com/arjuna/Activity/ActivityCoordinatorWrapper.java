/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity;

import com.arjuna.CosTransactions.OTS;
import com.arjuna.CosTransactions.OTS_Current;
import org.omg.CosTransactions.*;
import org.omg.CosActivity.*;
import java.util.*;

import org.omg.CORBA.BAD_OPERATION;
import org.omg.CORBA.SystemException;

/*
 * We only actually create an ActivityCoordinator when the first
 * action is registered. This class acts as a place-holder until
 * then.
 *
 * The only potential problem with this is that the enclosing
 * transaction hierarchy may change between the activity being
 * "created" and us actually creating the activity!
 */

/*
 * Once created, add to the reaper!
 *
 * We don't do that at present!
 */

public class ActivityCoordinatorWrapper
{

public ActivityCoordinatorWrapper (ActivityCoordinatorWrapper parent,
				   int timeout)
    {
	_parentWrapper = parent;
	_coordImple = null;
	_coordRef = null;
	_timeout = timeout;
	_failOnly = false;
	_enclosingTransaction = getEnclosingTx();
	_valid = true;
	_completed = false;
    }

public ActivityCoordinatorWrapper (ActivityCoordinator ref)
    {
	_parentWrapper = null;
	_coordImple = null;
	_coordRef = ref;
	_timeout = 0;
	_failOnly = false;
	_enclosingTransaction = getEnclosingTx();
	_valid = true;
	_completed = false;

	try
	{
	    _parentWrapper = new ActivityCoordinatorWrapper(ref.get_parent_coordinator());
	}
	catch (Exception e)
	{
	    _valid = false;
	}
    }

public final boolean valid ()
    {
	return _valid;
    }
    
public final boolean isLocal ()
    {
	if (_coordImple != null)
	    return true;
	else
	{
	    /*
	     * If lazily creating the coordinator then we are
	     * local!
	     */

	    if ((_coordImple == null) && (_coordRef == null))
		return true;
	    else
		return false;
	}
    }

public void destroy () throws AlreadyDestroyed
    {
	if (_coordImple != null)
        {
	    _coordImple.destroy();
	    _coordImple = null;
	}
    }

public final org.omg.CosActivity.Status get_status () throws SystemException
    {
	if (_completed)
	    return org.omg.CosActivity.Status.StatusCompleted;
	
	if ((_coordImple == null) && (_coordRef == null)) // no coordinator created yet
	{
	    return org.omg.CosActivity.Status.StatusActive;
	}
	else
	{
	    if (_coordImple != null)
		return _coordImple.get_status();
	    else
		return _coordRef.get_status();
	}
    }

    /*
     * If the activity has not been created yet then the default
     * completion status is CompletionStatusFail (see specification).
     */

public final org.omg.CosActivity.CompletionStatus get_completion_status ()
    {
	if (_valid && (_coordImple != null))
	    return _coordImple.getCompletionStatus();
	else
	    return CompletionStatus.CompletionStatusFail;
    }

public final void set_completion_status (CompletionStatus cs) throws SystemException
    {
	createActivityCoordinator();  // null op if already done

	if (_valid && (_coordImple != null))
	    _coordImple.setCompletionStatus(cs);
	else
	    throw new BAD_OPERATION();  // should be INVALID_ACTIVITY
    }

public final String get_completion_signal_set ()
    {
	if (_coordImple != null)
	    return _coordImple.getCompletionSignalSet();
	else
	    return null; // shouldn't get here anyway!
    }

public final void set_completion_signal_set (String signalSetName) throws SystemException
    {
	createActivityCoordinator();  // null op if already done

	if (_valid && (_coordImple != null))
	    _coordImple.setCompletionSignalSet(signalSetName);
	else
	    throw new BAD_OPERATION();  // should be INVALID_ACTIVITY
    }
    
public final Outcome complete () throws SignalSetUnknown, ActivityPending, ChildContextPending, SystemException
    {
	if (!_valid || _completed)
	    throw new BAD_OPERATION();  // should be INVALID_ACTIVITY
	else
	{
	    Outcome o = null;

	    if (_coordImple != null)
		o = _coordImple.complete();

	    _completed = true;

	    return o;
	}
   }

public final String get_activity_name () throws SystemException
    {
	createActivityCoordinator();  // null op if already done
	
	if (_coordImple != null)
	    return _coordImple.get_activity_name();
	else
	    return _coordRef.get_activity_name();
    }

public final ActivityCoordinatorImple getCoordinatorImple ()
    {
	createActivityCoordinator();  // null op if already done

	return _coordImple;
    }

public final ActivityCoordinator get_coordinator () throws SystemException
    {
	createActivityCoordinator();  // null op if already done

	if ((_coordImple != null) && (_coordRef == null))
	    _coordRef = _coordImple.getReference();
	
	return _coordRef;
    }

public final ActivityCoordinator get_parent_coordinator () throws SystemException
    {
	if (_parentWrapper != null)
	    return _parentWrapper.get_coordinator();
	else
	    return null;
    }

public final int get_timeout ()
    {
	return _timeout;
    }

    /*
     * Could possibly create id lazily and then pass it to the activity when
     * we actually create it, rather than creating the activity just to get
     * the id.
     */

public byte[] get_global_id () throws SystemException
    {
	createActivityCoordinator();  // null op if already done

	if (_valid && (_coordImple != null))
	    return _coordImple.get_global_id();
	else
	    throw new BAD_OPERATION();
    }

public boolean equals (Object o)
    {
	if (o == null)
	    return false;
	
	if (o instanceof ActivityCoordinatorWrapper)
	{
	    if (o == this)
		return true;
	    else
	    {
		ActivityCoordinatorWrapper act = (ActivityCoordinatorWrapper) o;
		
		if (act.getCoordinatorImple() == getCoordinatorImple())
		    return true;
	    }
	}
	
	return false;
    }

public final void addTransaction (Control tx) throws SystemException
    {
	 createActivityCoordinator();  // null op if already done
	 
	 if (_coordImple != null)
	     _coordImple.addTransaction(tx);
	 else
	     throw new BAD_OPERATION();
    }
	
public final void removeTransaction (Control tx) throws SystemException
    {
	 if (_coordImple != null)
	     _coordImple.removeTransaction(tx);
	 else
	     throw new BAD_OPERATION();	
    }
    
final ActivityCoordinatorWrapper getParentCoordinator ()
    {
	return _parentWrapper;
    }

final Control getEnclosingTransaction ()
    {
	return _enclosingTransaction;
    }
    
final Vector getEnclosedTransactions ()
    {
	if (_coordImple != null)
	    return _coordImple.getEnclosedTransactions();
	else
	    return null;
    }
    
final void addChildActivity (ActivityCoordinatorImple coord) throws SystemException
     {
	 createActivityCoordinator();  // null op if already done
	 
	 if (_coordImple != null)
	     _coordImple.addChildActivity(coord);
	 else
	     throw new BAD_OPERATION();
     }

final void removeChildActivity (ActivityCoordinatorImple coord) throws SystemException
     {
	 if (_coordImple != null)
	     _coordImple.removeChildActivity(coord);
	 else
	     throw new BAD_OPERATION();
     }

final synchronized void addThread ()
     {
	 createActivityCoordinator();  // null op if already done

	 if (_coordImple != null)
	     _coordImple.addThread();
	 else
	     throw new BAD_OPERATION();
     }

final synchronized void addThread (Thread ct)
     {
	 createActivityCoordinator();  // null op if already done

	 if (_coordImple != null)
	     _coordImple.addThread(ct);
	 else
	     throw new BAD_OPERATION();
     }

final synchronized void removeThread ()
     {
	 if (_coordImple != null)
	     _coordImple.removeThread();
	 else
	     throw new BAD_OPERATION();
     }

final synchronized void removeThread (Thread ct)
     {
	 if (_coordImple != null)
	     _coordImple.removeThread(ct);
	 else
	     throw new BAD_OPERATION();
     }

private final void createActivityCoordinator ()
    {
	if ((_coordImple == null) && (_coordRef == null))
	{
	    if (_parentWrapper == null)
	    {
		if (_enclosingTransaction != null)
		    _coordImple = ActivityFactory.factory().create(_timeout, _enclosingTransaction);
		else
		    _coordImple = ActivityFactory.factory().create(_timeout);
	    }
	    else
	    {
		_coordImple = ActivityFactory.factory().createSubactivity(_parentWrapper.getCoordinatorImple(), _timeout);
	    }

	    /*
	     * Did an error happened before we created the activity?
	     * Typically we could not get the enclosing transaction
	     * context for this activity when it was "created".
	     */

	    if (_failOnly)
	    {
		try
		{
		    _coordImple.setCompletionStatus(CompletionStatus.CompletionStatusFailOnly);
		}
		catch (Exception e)
		{
		    /*
		     * Could not set the completion status!
		     */

		    System.err.println(e);

		    _valid = false;
		}
	    }
	}
    }

private final Control getEnclosingTx ()
    {
	OTS_Current current = OTS.current();
	
	if (current != null)
	{
	    try
	    {
		if (current.get_status() == org.omg.CosTransactions.Status.StatusActive)
		{
		    return current.get_control();
		}
	    }
	    catch (SystemException e)
	    {
		_failOnly = true;
	    }
	}
	
	return null;
    }

private ActivityCoordinatorWrapper _parentWrapper;
private ActivityCoordinatorImple   _coordImple;
private ActivityCoordinator        _coordRef;
private int                        _timeout;
private boolean                    _failOnly;
private Control                    _enclosingTransaction;
private boolean                    _valid;
private boolean                    _completed;
    
};
