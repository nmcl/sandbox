/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity;

import com.arjuna.Activity.Signals.*;
import com.arjuna.Activity.SignalSets.*;
import org.omg.CosTransactions.*;
import org.omg.CosActivity.CompletionStatus;
import org.omg.CosActivity.*;
import org.omg.CORBA.*;
import java.util.*;

import org.omg.CosActivity.SignalSetAlreadyRegistered;
import org.omg.CosActivity.SignalSetUnknown;
import org.omg.CosActivity.ActionNotFound;
import org.omg.CORBA.BAD_PARAM;
import org.omg.CORBA.SystemException;

/*
 * This object maintains the lists of Actions and the names of the SignalSets
 * they have been registered with, and the global Actions (these are Actions
 * that receive every Signal sent).
 */

class IntentionsList
{

public IntentionsList ()
    {
	_actions = null;
	_globalActions = null;
    }

public synchronized void addSignalSet (SignalSet signal_set_name) throws SignalSetAlreadyRegistered, SystemException
    {
	if (signal_set_name == null)
	    throw new BAD_PARAM();
	
	if (_actions == null)
	    _actions = new Hashtable();
	
	Vector v = (Vector) _actions.get(signal_set_name);
	
	if (v != null)
	    throw new SignalSetAlreadyRegistered();
	else
	    _actions.put(signal_set_name, new Vector());
    }

public synchronized void removeSignalSet (String signal_set_name) throws SignalSetUnknown, SystemException
    {
	if (signal_set_name == null)
	    throw new BAD_PARAM();

	Vector v = null;
	
	if (_actions != null)
	    v = (Vector) _actions.remove(signal_set_name);
	
	if (v == null)
	    throw new SignalSetUnknown();
	else
	    v = null;
    }

public synchronized void addAction (Action act, String signal_set_name,
				    int priority) throws SignalSetUnknown, SystemException
    {
	if ((act == null) || (signal_set_name == null))
	    throw new BAD_PARAM();

	Vector v = null;
	
	if (_actions != null)
	    v = (Vector) _actions.get(signal_set_name);
		
	if (v == null)
	    throw new SignalSetUnknown();
	else
	{
	    /*
	     * Shuffles elements up to make room?
	     */

	    v.insertElementAt(act, priority);
	}
    }
 
public synchronized void removeAction (Action act) throws ActionNotFound, SystemException
    {
	if (act == null)
	    throw new BAD_PARAM();
	
	if (_actions == null)
	    throw new ActionNotFound();
	
	Enumeration e = _actions.elements();
		
	while (e.hasMoreElements())
	{
	    Vector v = (Vector) e.nextElement();
		    
	    if (v != null)
	    {
		if (v.removeElement(act))
		    return;
	    }
	}

	/*
	 * If we get here then the action was not present in any
	 * of the signal set lists!
	 */

	throw new ActionNotFound();
    }
 
public synchronized void addActions (Action[] acts, String signal_set_name,
				     int priority) throws SignalSetUnknown, SystemException
    {
	if (acts == null)
	    throw new BAD_PARAM();

	Vector v = null;
	
	if (_actions != null)
	    v = (Vector) _actions.get(signal_set_name);
		
	if (v == null)
	    throw new SignalSetUnknown();
	else
	{
	    for (int i = 0; i < acts.length; i++)
	    {
		/*
		 * Shuffles elements up to make room?
		 */
		
		v.insertElementAt(acts[i], priority);
	    }
	}	
    }
 
public Action[] removeActions (Action[] acts) throws SystemException
    {
	if (acts == null)
	    throw new BAD_PARAM();
	
	Vector failed = null;

	for (int i = 0; i < acts.length; i++)
	{
	    try
	    {
		removeAction(acts[i]);
	    }
	    catch (ActionNotFound e)
	    {
		if (failed == null)
		    failed = new Vector();
		
		failed.insertElementAt(acts, 0);
	    }
	}

	if (failed != null)
	{
	    Action[] failures = new Action[failed.size()];
	    
	    for (int j = 0; j < failed.size(); j++)
		failures[j] = (Action) failed.elementAt(j);

	    return failures;
	}
	else
	    return null;
    }

public synchronized void addGlobalAction (Action act,
					  int priority) throws SystemException
    {
	if (act == null)
	    throw new BAD_PARAM();
	
	if (_globalActions == null)
	    _globalActions = new Vector();
	
	_globalActions.insertElementAt(act, priority);
    }
 
public synchronized void removeGlobalAction (Action act) throws ActionNotFound, SystemException
    {
	if (act == null)
	    throw new BAD_PARAM();
	
	if ((_globalActions == null) || (!_globalActions.removeElement(act)))
	    throw new ActionNotFound();
    }
 
public synchronized int getNumberRegisteredActions (String signal_set_name) throws SignalSetUnknown, SystemException
    {
	if (signal_set_name == null)
	    throw new BAD_PARAM();
	
	Vector v = null;
	
	if (_actions != null)
	    v = (Vector) _actions.get(signal_set_name);

	if (v == null)
	    throw new SignalSetUnknown();
	else
	    return v.size();
    }
 
public synchronized Vector getActions (String signalSetName) throws SignalSetUnknown
    {
	if (signalSetName == null)
	    throw new BAD_PARAM();

	Vector v = null;
	
	if (_actions != null)
	    v = (Vector) _actions.get(signalSetName);

	if (v == null)
	    throw new SignalSetUnknown();
	else
	    return v;
    }

public synchronized Action[] get_actions (String signalSetName) throws SignalSetUnknown
    {
	Vector v = getActions(signalSetName);
	
	if (v != null)
	{
	    Action[] act = new Action[v.size()];
	    
	    for (int i = 0; i < act.length; i++)
		act[i] = (Action) v.elementAt(i);

	    return act;
	}
	else
	    throw new SignalSetUnknown();
    }
    
public synchronized Vector getGlobalActions ()
    {
	return _globalActions;
    }

private Hashtable _actions;
private Vector    _globalActions;

};
