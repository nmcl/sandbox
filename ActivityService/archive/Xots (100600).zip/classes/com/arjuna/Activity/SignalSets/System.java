/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity.SignalSets;

/*
 * The system signal sets.
 */

public class System
{

public static final String Synchronization = "Synchronization";
public static final String ChildLifetime = "ChildLifetime";
 
};
