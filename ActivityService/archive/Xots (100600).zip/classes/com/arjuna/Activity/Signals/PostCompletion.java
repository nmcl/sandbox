/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity.Signals;

import com.arjuna.Activity.Utility;
import org.omg.CosActivity.CompletionStatus;
import org.omg.CosActivity.Signal;
import org.omg.CORBA.*;

public class PostCompletion
{

public static Signal getSignal (CompletionStatus cs)
    {
	return new Signal(Utility.getCompletionStatus(cs),
			  "Synchronization", null);
    }
    
};
