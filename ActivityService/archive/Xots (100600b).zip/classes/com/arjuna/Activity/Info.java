
/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.  
 *
 * $Id: Info.javatmpl,v 1.3.2.1 2000/04/25 08:36:25 nmcl Exp $
 */










package com.arjuna.Activity;

import com.arjuna.JavaHarness.ModuleInfo;
import java.io.*;
import java.util.*;

public class Info implements ModuleInfo
{

public Info ()
    {
	this("");
    }
    
public Info (String s)
    {
	_preString  = s;

	_attributes = new Hashtable();
	
	_attributes.put("MODULE", "XOTS");
	_attributes.put("SOURCE IDENTIFIER", "unknown");
	_attributes.put("BUILD_INFORMATION", "Arjuna Solutions Ltd. [unknown]");
	_attributes.put("VERSION", "1.0.0");
	_attributes.put("DATE", "Wed May 10 14:55:22 2000");
	_attributes.put("NOTES", "none");
    }
    
public final void setPreString (String s)
    {
	_preString = s;
    }
    
public final void getInfo ()
    {
	System.out.println(toString());
    }

public String query (String attribute)
    {
	return (String) _attributes.get(attribute);
    }

public ModuleInfo[] constituents ()
    {
	return null;
    }
    
public String toString ()
    {
	String module = _preString+"MODULE: "+"XOTS";
	String source = _preString+"SOURCE IDENTIFIER: "+"unknown";
	String build = _preString+"BUILD INFORMATION: "+"Arjuna Solutions Ltd. [unknown]";
	String version = _preString+"VERSION: "+"1.0.0";
	String date = _preString+"DATE: "+"Wed May 10 14:55:22 2000";
	String notes = _preString+"NOTES: "+"none";
	
	return module+"\n"+source+"\n"+build+"\n"+version+"\n"+date+"\n"+notes;
    }

private String _preString;
private Hashtable _attributes;
    
};
