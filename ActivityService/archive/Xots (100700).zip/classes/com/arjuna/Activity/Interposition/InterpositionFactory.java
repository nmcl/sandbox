/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity.Interposition;

import org.omg.CosActivity.*;
import org.omg.CORBA.*;

import org.omg.CORBA.SystemException;

public class InterpositionFactory
{

public ActivityToken create (ActivityContext ctx) throws InvalidToken, SystemException
    {
	if (ctx == null)
	    throw new InvalidToken();

	/*
	 * We don't use the implementation_specific_data portion of the
	 * ActivityContext so we must remember to null them out.
	 */

    }
	
};
