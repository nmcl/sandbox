/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity.Signals;

import com.arjuna.Activity.Utility;
import org.omg.CosActivity.CompletionStatus;
import org.omg.CosActivity.Signal;
import org.omg.CORBA.*;

public class ChildLifetimeComplete
{

public static Signal getSignal ()
    {
	return new Signal("childLifetime", "childComplete", null);
    }
    
};
