/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity;

public class Defaults
{

public static final int DEFAULT_TIMEOUT = 120;  // timeout in seconds
    
};
