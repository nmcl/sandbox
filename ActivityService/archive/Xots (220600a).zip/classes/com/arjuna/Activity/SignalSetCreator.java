/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity;

import org.omg.CosActivity.SignalSet;
import org.omg.CORBA.*;

public interface SignalSetCreator
{

public String name ();
public SignalSet create ();
    
};
