/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity.Signals;

import com.arjuna.OrbCommon.ORBInterface;
import org.omg.CosActivity.CompletionStatus;
import org.omg.CosActivity.CompletionStatusHelper;
import org.omg.CosActivity.Signal;
import org.omg.CORBA.*;

public class PreCompletion
{

public static Signal getSignal (CompletionStatus cs)
    {
	Any isd = ORBInterface.orb().create_any();

	CompletionStatusHelper.insert(isd, cs);

	return new Signal("preCompletion",
			  "Synchronization", isd);
    }
 
};
