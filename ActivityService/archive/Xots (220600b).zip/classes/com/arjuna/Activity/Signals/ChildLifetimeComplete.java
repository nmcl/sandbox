/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity.Signals;

import com.arjuna.OrbCommon.ORBInterface;
import com.arjuna.Activity.Utility;
import org.omg.CosActivity.GlobalIdHelper;
import org.omg.CosActivity.Signal;
import org.omg.CORBA.*;

public class ChildLifetimeComplete
{

    /*
     * We have a single SignalSet, and the coordinator will
     * fill in the isd with the child activity's global id.
     */

public static Signal getSignal (byte[] globalId)
    {
	Any isd = ORBInterface.orb().create_any();

	GlobalIdHelper.insert(isd, globalId);

	return new Signal("ChildLifetime", "childComplete", isd);
    }
    
};
