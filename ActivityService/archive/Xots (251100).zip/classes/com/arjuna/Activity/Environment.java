/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity;

public class Environment
{

public static final String ACTIVITY_REAPER_MODE = "ACTIVITY_REAPER_MODE";
public static final String ACTIVITY_REAPER_TIMEOUT = "ACTIVITY_REAPER_TIMEOUT";
public static final String ACTION_MANAGER = "ACTION_MANAGER";
    
};
