/*
 * Copyright (C) 2000,
 *
 * Arjuna Solutions Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id$
 */

package com.arjuna.Activity.Interposition;

import com.arjuna.Activity.ActivityCoordinator.ActivityCoordinator;
import org.omg.CosActivity.*;
import org.omg.CORBA.*;

import org.omg.CORBA.SystemException;

public class SubordinateCoordinator extends ActivityCoordinator
{

public SubordinateCoordinator ()
    {
    }
 
};
