#include <sys/time.h>
#include <sys/timeb.h>
#include "lwp.h"
struct sem *s;

void f (int n)
{
	while (n--)
		yieldp ();
	signals (s);
	suicidep ();
}

void g (void)
{
	suicidep ();
}

main ()
{
	int n, t;
	struct timeb ts, te;

	initlp (1);
	s = creats (0);
	creatp (1, f, 4096, 5000, 0, 0);
	creatp (1, f, 4096, 5000, 0, 0);
	ftime (&ts);
	waits (s);
	waits (s);
	ftime (&te);
	t = 1000*(te.time-ts.time) + te.millitm - ts.millitm;
	free (s);
	printf ("Context switching: %d ms /10000\n", t);

	ftime (&ts);
	for (n=10000; n--; )
		creatp (2, g, 4096, 0, 0, 0);
	ftime (&te);
	t = 1000*(te.time-ts.time) + te.millitm - ts.millitm;
	printf ("Process creation: %d ms /10000\n", t);
}
