#include "resizable.h"

Resizable::Resizable() {};
Resizable::Resizable(Glyph *g) : MonoGlyph(g) {};

void Resizable::resize(Coord, Coord) {}
