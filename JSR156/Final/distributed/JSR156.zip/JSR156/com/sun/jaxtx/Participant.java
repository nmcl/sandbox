package com.sun.jaxtx;

public class Participant
{

    public String process_message (String sig)
    {
	return null;
    }

    public String identity ()
    {
	return null;
    }
    
}
