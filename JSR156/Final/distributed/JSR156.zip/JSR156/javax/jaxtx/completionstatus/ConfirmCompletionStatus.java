package javax.jaxtx.completionstatus;

/**
 * The transaction should complete in a success condition. When in
 * this state the transaction may be moved into any other state.
 */

public class ConfirmCompletionStatus implements CompletionStatus
{

}
