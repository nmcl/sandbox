package javax.jaxtx.extensions.as;

/**
 * The SignalSet is not known about (not registered).
 */

public class SignalSetUnknownException extends Exception
{

public SignalSetUnknownException ()
    {
	super();
    }

public SignalSetUnknownException (String s)
    {
	super(s);
    }

}
