package javax.jaxtx.model.btp;

import javax.jaxtx.status.Status;

/**
 * The inferior has prepared.
 */

public class PreparedStatus implements Status
{
    
}
