package javax.jaxtx.model.btp;

import javax.jaxtx.status.Status;

/**
 * The inferior is in the process of preparing.
 */

public class PreparingStatus implements Status
{
    
}
