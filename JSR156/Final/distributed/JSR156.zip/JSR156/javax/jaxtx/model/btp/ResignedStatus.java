package javax.jaxtx.model.btp;

import javax.jaxtx.status.Status;

/**
 * The inferior has resigned from the transaction.
 */

public class ResignedStatus implements Status
{
    
}
