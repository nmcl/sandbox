package javax.jaxtx.model.btp;

import javax.jaxtx.status.Status;

/**
 * The inferior is in the process of resigning from the transaction.
 */

public class ResigningStatus implements Status
{
    
}
