package javax.jaxtx.model.btp;

/**
 * The inferior votes that all of its inferiors have resigned from the
 * transaction. The transaction (atom) is terminated.
 */

public interface VoteResign extends Vote
{
    
}
