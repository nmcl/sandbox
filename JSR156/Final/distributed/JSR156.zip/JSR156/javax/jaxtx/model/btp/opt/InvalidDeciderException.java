package javax.jaxtx.model.btp.opt;

/**
 */

public class InvalidDeciderException extends Exception
{

public InvalidDeciderException ()
    {
	super();
    }

public InvalidDeciderException (String s)
    {
	super(s);
    }

}
