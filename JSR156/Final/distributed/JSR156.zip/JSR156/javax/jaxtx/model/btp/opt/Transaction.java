package javax.jaxtx.model.btp.opt;

/**
 * The Transaction is the interface that most participants will see.
 */

public interface Transaction extends Superior
{
}
