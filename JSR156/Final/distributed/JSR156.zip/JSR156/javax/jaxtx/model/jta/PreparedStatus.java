package javax.jaxtx.model.jta;

import javax.jaxtx.status.Status;

/**
 * The transaction has prepared.
 */

public class PreparedStatus implements Status
{
    
}
