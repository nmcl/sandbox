/*
 * Copyright (C) 2003,
 *
 * Arjuna Technologies Limited,
 * Newcastle upon Tyne,
 * Tyne and Wear,
 * UK.
 *
 * $Id: Aborted.java,v 1.1 2003/02/03 16:24:45 nmcl Exp $
 */

package com.arjuna.wst;

/**
 * Aborted: the participant has aborted and the transaction should also
 * attempt to do so.
 */

public class Aborted implements Vote
{
}
