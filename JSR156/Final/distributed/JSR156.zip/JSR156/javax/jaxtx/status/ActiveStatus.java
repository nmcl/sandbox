package javax.jaxtx.status;

/**
 * The transaction is in the active state, i.e., it has not yet begun to
 * terminate.
 */

public class ActiveStatus implements Status
{
    
}
