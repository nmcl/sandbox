package javax.jaxtx.status;

/**
 * The transaction completed in a cancel state.
 */

public class CompletedCancelStatus implements Status
{
    
}
