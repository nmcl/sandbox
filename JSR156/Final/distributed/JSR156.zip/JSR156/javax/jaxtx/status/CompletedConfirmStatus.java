package javax.jaxtx.status;

/**
 * The transaction completes in a confirm state.
 */

public class CompletedConfirmStatus implements Status
{
    
}
