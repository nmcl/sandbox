package javax.jaxtx.status;

/**
 * The transaction is completing in a cancel state.
 */

public class CompletingCancelStatus implements Status
{
    
}
