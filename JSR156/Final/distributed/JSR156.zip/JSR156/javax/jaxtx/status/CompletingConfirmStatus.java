package javax.jaxtx.status;

/**
 * The transaction is completing in a confirm state.
 */

public class CompletingConfirmStatus implements Status
{
    
}
