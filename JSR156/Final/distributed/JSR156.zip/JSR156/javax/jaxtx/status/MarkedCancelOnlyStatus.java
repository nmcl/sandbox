package javax.jaxtx.status;

/**
 * The transaction state has been marked as cancel only, so its only outcome
 * is to eventually cancel.
 */

public class MarkedCancelOnlyStatus implements Status
{
    
}
