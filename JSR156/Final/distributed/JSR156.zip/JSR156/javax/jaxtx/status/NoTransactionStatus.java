package javax.jaxtx.status;

/**
 * There is no transaction associated with the invoking thread.
 */

public class NoTransactionStatus implements Status
{
    
}
