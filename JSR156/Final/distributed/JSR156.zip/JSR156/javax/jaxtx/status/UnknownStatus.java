package javax.jaxtx.status;

/**
 * The state of the transaction is currently unknown. This should be a
 * transient, so retrying will eventually return one of the other states.
 */

public class UnknownStatus implements Status
{
    
}
