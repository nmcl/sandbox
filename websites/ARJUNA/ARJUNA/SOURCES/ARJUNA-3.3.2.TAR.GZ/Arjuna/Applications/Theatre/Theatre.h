/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */


/*
 * $Id: Theatre.h,v 1.1 1993/11/03 12:24:27 nmcl Exp $
 */

class Uid;

extern char* TheatreHost;
extern Uid*  TheatreUid;
extern int   TheatreNew;
