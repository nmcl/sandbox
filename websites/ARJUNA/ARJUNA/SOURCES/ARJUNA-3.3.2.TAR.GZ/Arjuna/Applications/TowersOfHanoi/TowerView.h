/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */

/*
 * $Id: TowerView.h,v 1.1 1993/11/03 12:25:33 nmcl Exp $
 */

#ifndef TOWERVIEW_H_
#define TOWERVIEW_H_

class Uid;

extern char* PinHost;
extern Uid*  PinUid;

#endif
