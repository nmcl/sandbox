/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: Types.h,v 1.1 1994/12/09 11:38:29 ngdp Exp $
 */

#ifndef STUBGEN_TYPES_H_
#define STUBGEN_TYPES_H_

#ifndef COMMONT_H_
#  include <Common/CommonT.h>
#endif

#endif

