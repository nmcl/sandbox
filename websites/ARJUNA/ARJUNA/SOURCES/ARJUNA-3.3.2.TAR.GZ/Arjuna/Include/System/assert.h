/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: assert.h,v 1.1 1993/11/03 14:32:36 nmcl Exp $
 */

#ifndef ASSERT_H_
#define ASSERT_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <assert.h>

#endif
