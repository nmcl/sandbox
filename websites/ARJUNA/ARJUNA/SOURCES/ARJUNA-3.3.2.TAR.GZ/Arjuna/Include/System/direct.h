/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: direct.h,v 1.1 1996/04/15 14:17:57 nmcl Exp $
 */

#ifndef DIRECT_H_
#define DIRECT_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <direct.h>

#endif
