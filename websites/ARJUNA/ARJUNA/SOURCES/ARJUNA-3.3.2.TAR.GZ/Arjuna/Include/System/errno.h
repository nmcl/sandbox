/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: errno.h,v 1.1 1993/11/03 14:32:41 nmcl Exp $
 */

#ifndef ERRNO_H_
#define ERRNO_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <errno.h>

#endif
