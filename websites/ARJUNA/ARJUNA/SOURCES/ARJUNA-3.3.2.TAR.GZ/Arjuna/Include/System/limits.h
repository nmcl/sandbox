/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: limits.h,
 */

#ifndef LIMITS_H_
#define LIMITS_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <limits.h>

#endif
