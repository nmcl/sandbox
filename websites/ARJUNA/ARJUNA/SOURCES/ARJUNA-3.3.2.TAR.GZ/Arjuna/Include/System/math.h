/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: math.h,v 1.1 1996/07/31 13:26:04 nmcl Exp $
 */

#ifndef MATH_H_
#define MATH_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <math.h>

#endif
