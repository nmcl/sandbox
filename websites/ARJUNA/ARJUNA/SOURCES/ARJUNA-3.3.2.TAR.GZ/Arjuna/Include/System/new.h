/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: new.h,v 1.1 1993/11/03 14:32:55 nmcl Exp $
 */

#ifndef NEW_H_
#define NEW_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <new.h>

#endif
