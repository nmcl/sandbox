/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: osfcn.h,v 1.1 1993/11/03 14:32:56 nmcl Exp $
 */

#ifndef OSFCN_H_
#define OSFCN_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <osfcn.h>

#endif
