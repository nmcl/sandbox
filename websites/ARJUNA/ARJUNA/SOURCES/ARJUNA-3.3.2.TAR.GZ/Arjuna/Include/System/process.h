/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: process.h,v 1.1 1996/04/15 14:17:58 nmcl Exp $
 */

#ifndef PROCESS_H_
#define PROCESS_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <process.h>

#endif
