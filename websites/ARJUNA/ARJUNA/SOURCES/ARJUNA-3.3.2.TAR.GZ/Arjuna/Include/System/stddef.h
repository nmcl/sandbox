/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: stddef.h,v 1.4 1994/11/29 13:44:43 ngdp Exp $
 */

#ifndef  STDDEF_H_
#define  STDDEF_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <stddef.h>

#endif
