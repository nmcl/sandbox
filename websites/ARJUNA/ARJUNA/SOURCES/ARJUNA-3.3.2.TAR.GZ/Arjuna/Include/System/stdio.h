/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: stdio.h,v 1.1 1993/11/03 14:33:10 nmcl Exp $
 */

#ifndef STDIO_H_
#define STDIO_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <stdio.h>

#endif
