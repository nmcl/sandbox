/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: limits.,
 */

#ifndef LIMITS_H_
#define MALLOC_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <limits.h>

#endif
