/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: signal.h,v 1.1 1993/11/03 14:34:33 nmcl Exp $
 */

#ifndef SYS_SIGNAL_H_
#define SYS_SIGNAL_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <sys/signal.h>

#endif
