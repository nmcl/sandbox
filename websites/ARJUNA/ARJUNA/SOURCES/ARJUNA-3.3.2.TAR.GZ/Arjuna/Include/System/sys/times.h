/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: times.h,
 */

#ifndef SYS_TIMES_H_
#define SYS_TIMES_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <sys/times.h>

#endif
