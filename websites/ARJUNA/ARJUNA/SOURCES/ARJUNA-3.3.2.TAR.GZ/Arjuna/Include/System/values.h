/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: values.h,v 1.1 1993/11/03 14:33:29 nmcl Exp $
 */

#ifndef VALUES_H_
#define VALUES_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <values.h>

#endif
