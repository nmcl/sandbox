/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: wchar.h,v 1.1 1996/04/15 14:18:03 nmcl Exp $
 */

#ifndef WCHAR_H_
#define WCHAR_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <wchar.h>

#endif
