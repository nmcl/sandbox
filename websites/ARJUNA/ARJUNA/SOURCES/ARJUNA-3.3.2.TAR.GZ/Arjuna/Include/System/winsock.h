/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: winsock.h,v 1.1 1996/04/15 14:18:04 nmcl Exp $
 */

#ifndef WINSOCK_H_
#define WINSOCK_H_

#ifdef STUB
#  pragma @NoRename
#endif

#include <winsock.h>

#endif
