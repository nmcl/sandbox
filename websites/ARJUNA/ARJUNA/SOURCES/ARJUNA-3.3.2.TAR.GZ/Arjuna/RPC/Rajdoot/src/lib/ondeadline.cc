/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */

/*
 * $Id: ondeadline.cc,v 1.1 1994/05/03 10:54:54 ngdp Exp $
 */

#ifndef RAJDOOT_ONDEADLINE_H_
#  include <RPC/Rajdoot/ondeadline.h>
#endif

jmp_buf  _rpcenv;	    /* Stack environment variable */
