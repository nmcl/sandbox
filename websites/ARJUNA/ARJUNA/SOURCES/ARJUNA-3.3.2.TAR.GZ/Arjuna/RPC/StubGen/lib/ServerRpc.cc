/*
 * Copyright (C) 1993
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: ServerRpc.cc,v 1.1 1994/06/01 14:26:01 ngdp Exp $
 */

static const char RCSid[] = "$Id: ServerRpc.cc,v 1.1 1994/06/01 14:26:01 ngdp Exp $";

#include <StubGen/ServerRpc.h>

ServerRpc::ServerRpc ()
{
}

ServerRpc::~ServerRpc ()
{
}
