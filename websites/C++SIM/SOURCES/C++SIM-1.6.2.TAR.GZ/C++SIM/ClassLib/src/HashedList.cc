/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */

#include <iostream.h>

#ifndef HASHEDLIST_H_
#  include "HashedList.h"
#endif

#ifndef PROCESSITERATOR_H_
#  include "ProcessIterator.h"
#endif

#ifndef ERROR_H_
#  include <Common/Error.h>
#endif

#if defined(DEBUG) && !defined(DEBUG_H_)
#  include <Common/Debug.h>
#endif


HashedList::HashedList (int size)
                       : listSize(size),
			 numberOfEntries(0)
{
    hashedList = new ProcessList* [listSize];

    for (int i = 0; i < listSize; i++)
	hashedList[i] = new ProcessList;
}

HashedList::~HashedList ()
{
    for (int i = 0; i < listSize; i++)
	delete hashedList[i];

    delete [] hashedList;
}

// returns the next process to be activated after current

const Process* HashedList::getNext (const Process* current) const
{
    Process* toReturn = (Process*) 0;

    // take care of boundary condition.

    if ((current == (Process*) 0) || (numberOfEntries == 0))
        return (Process*) 0;

    for (int i = 0; i < listSize; i++)
    {
	ProcessIterator iter(*hashedList[i]);
	Process *p = iter(), *n = (Process*) 0;

	while (p->evtime() <= current->evtime())
	{
	    if (n == (Process*) 0)
		n = p;             // record element
	    p = iter();
	}

	n = ((p->evtime() == current->evtime()) ? p : n);
	
	if (n)
	{
	    if (toReturn)
	    {
		if (n->evtime() < toReturn->evtime())
		    toReturn = n;
	    }
	    else
		toReturn = n;
	}
    }

    return toReturn;
}

void HashedList::Insert (Process &ToInsert, Boolean prior)
{
#ifdef DEBUG
    debug_stream << FUNCTIONS << FAC_PROCESSLISTS << VIS_PUBLIC;
    debug_stream << "void HashedList::Insert ( " << ToInsert.evtime() << ", "
		 << ((prior) ? "TRUE" : "FALSE") << " )" << endl;
#endif    

    numberOfEntries++;
    hashedList[timeToKey(ToInsert.evtime())]->Insert(ToInsert, prior);
}

Boolean HashedList::InsertBefore (Process& ToInsert, Process& Before)
{
#ifdef DEBUG
    debug_stream << FUNCTIONS << FAC_PROCESSLISTS << VIS_PUBLIC;
    debug_stream << "Boolean HashedList::InsertBefore ( " << ToInsert.evtime() << ", "
		 << Before.evtime() << " )" << endl;
#endif

    numberOfEntries++;
    return hashedList[timeToKey(Before.evtime())]->InsertBefore(ToInsert, Before);
}

Boolean HashedList::InsertAfter (Process &ToInsert, Process &After)
{
#ifdef DEBUG
    debug_stream << FUNCTIONS << FAC_PROCESSLISTS << VIS_PUBLIC;
    debug_stream << "Boolean HashedList::InsertAfter ( " << ToInsert.evtime() << ", "
		 << After.evtime() << " )" << endl;
#endif

    numberOfEntries++;    
    return hashedList[timeToKey(After.evtime())]->InsertAfter(ToInsert, After);
}

Process* HashedList::findMinimum () const
{
    Process* toReturn = (Process*) 0;

    for (int i = 0; i < listSize; i++)
    {
	ProcessIterator iter(*hashedList[i]);
	Process *p = iter();

	if (p)
	{
	    if (toReturn)
	    {
		if (p->evtime() < toReturn->evtime())
		    toReturn = p;
	    }
	    else
		toReturn = p;
	}
    }

    return toReturn;
}

Process* HashedList::Remove (const Process *element)
{
    if (numberOfEntries == 0)
	return (Process*) 0;
    
    // Change unspecified element to "remove head of list" request
    
    if (element == (Process*) 0)
	return Remove(findMinimum());

    Process* toReturn = (Process*) 0;
    int key = timeToKey(element->evtime());

    numberOfEntries--;
    
    if (!(*hashedList[key])[0])  // not in queue, so active/passive
	return (Process*) 0;

    return hashedList[key]->Remove(element);
}

ostream& HashedList::print (ostream& strm) const
{
    for (int i = 0; i < listSize; i++)
    {
        strm << "\nList element " << i << "\n";
	strm << *hashedList[i];
    }

    return strm;
}


#ifdef NO_INLINES
#  define HASHEDLIST_CC_
#  include "HashedList.n"
#  undef HASHEDLIST_CC_
#endif
