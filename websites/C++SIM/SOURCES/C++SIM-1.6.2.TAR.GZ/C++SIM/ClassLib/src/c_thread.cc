/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: c_thread.cc,v 1.5 1996/12/03 10:22:28 nmcl Exp $
 */

#ifndef CONFIGURE_H_
#  include <Config/Configure.h>
#endif

#include <setjmp.h>
#include <stdlib.h>

#ifndef ERROR_H_
#  include <Common/Error.h>
#endif

#ifndef C_THREAD_H_
#  include <ClassLib/c_thread.h>
#endif

static mutex_t   globalMutex;

long      C_Thread::base_key = 0;
C_Thread* C_Thread::mainThread = (C_Thread*) 0;
long      C_Thread::mainThreadID = 0;


C_Thread::C_Thread (cthread_t mThread)
		   : dead(FALSE)
{
    thread_key = C_Thread::base_key++;
    cid = cthread_self();
    cthread_set_data(cid, (any_t) &thread_key);

    (void) mutex_alloc(&globalMutex, N_CURRENT);
    mutex_lock(globalMutex);
    
    if (mutex_alloc(&mx, N_CURRENT) != T_SUCCEED)
    {
	error_stream << FATAL
		     << "C_Thread error - cannot allocate thread mutex!"
		     << endl;
	abort();
    }

    mutex_lock(mx);

    C_Thread::mainThreadID = thread_key;
    C_Thread::mainThread = this;
}

C_Thread::C_Thread ()
		   : dead(FALSE)
{
    thread_key = C_Thread::base_key++;

    if (mutex_alloc(&mx, N_CURRENT) != T_SUCCEED)
    {
	error_stream << FATAL
		     << "C_Thread error - cannot allocate thread mutex!"
		     << endl;
	abort();
    }

    mutex_lock(mx);

    any_t p1 = (any_t) this;

    cid = cthread_fork(C_Thread::Execute, p1, N_CURRENT);
    (void) cthread_detach(cid);
}

C_Thread::C_Thread (unsigned long)
		   : dead(FALSE)
{
    thread_key = C_Thread::base_key++;

    if (mutex_alloc(&mx, N_CURRENT) != T_SUCCEED)
    {
	error_stream << FATAL
		     << "C_Thread error - cannot allocate thread mutex!"
		     << endl;
	abort();
    }

    mutex_lock(mx);

    any_t p1 = (any_t) this;

    cid = cthread_fork(C_Thread::Execute, p1, N_CURRENT);
    (void) cthread_detach(cid);
}

C_Thread::~C_Thread ()
{
    if (!dead)
    {
	mutex_clear(mx);
	cthread_yield();  // let threads wake up
	mutex_free(mx);
	cthread_set_data(cid, NULL);

	terminateThread();
    }
}

long C_Thread::Current_Thread () const
{
    any_t p1 = cthread_data(cthread_self());

    return *(long*) p1;
}

void C_Thread::terminateThread ()
{
    /*
     * If one thread terminates another then we must switch contexts
     * to the terminating thread for it to tidy itself up. Then that
     * thread must switch back to us.
     */

    dead = TRUE;

    if (cid != cthread_self())
    {
	C_Thread::Resume();

	mutex_lock(globalMutex);
    }
    else
	cthread_exit(NULL);
}

void C_Thread::Suspend ()
{
    if (cthread_self() == cid)
	mutex_lock(mx);

    if (dead)
    {
	mutex_unlock(globalMutex);
	terminateThread();
    }
}

void C_Thread::Resume ()
{
    mutex_unlock(mx);
}

void* C_Thread::Execute (void* p1)
{
    C_Thread* _p1 = (C_Thread*) p1;

    cthread_set_data(_p1->cid, (any_t) &_p1->thread_key);
    mutex_lock(_p1->mx);

    if (!_p1->dead)
	_p1->Body();
    else
	mutex_unlock(globalMutex);
    
    cthread_exit(NULL);
}

ostream& C_Thread::print (ostream& strm) const
{
    strm << "Thread type is C Thread.\n";
    return Thread::print(strm);
}

//
// Getting the main thread into the thread list...
//

class Main_CThread : public C_Thread
{
public:
    Main_CThread (cthread_t);
    ~Main_CThread ();

    static void dummyMain ();

    void Body ();

    static jmp_buf env;
};

jmp_buf Main_CThread::env;

Main_CThread::Main_CThread (cthread_t cid) : C_Thread(cid) {}

Main_CThread::~Main_CThread () {}

void Main_CThread::Body () {}

/*
 * We have to do this because the cthreads approach to making "main"
 * a thread is to force it (the first thread) into a separate procedure
 * for it to run. When it returns from this procedure the application ends.
 * This is different to all of the other threads packages, which simply
 * treat the main thread as automatically running within "main". Rather
 * than make all of the other packages conform to cthreads, we can force
 * cthreads to work in the manner of the other scheme by making the main
 * thread jump back to the calling point of cthread_init using setjmp/longjmp.
 * This is messy, but it allows us to still write applications which do not
 * have to be specific to a given threads package.
 * Don't try this at home, folks!
 */

void Main_CThread::dummyMain ()
{
    longjmp(Main_CThread::env, 1);
}

/*
 * Here is the thread specific initialization code.
 */

void Thread::Initialize ()
{
    if (!_initialized)
    {
	_initialized = TRUE;	
	if (setjmp(Main_CThread::env) == 0)
	    (void) cthread_init(1, Main_CThread::dummyMain);

	new Main_CThread(cthread_self());
    }
}

void Thread::Exit (int ret)
{
    exit(ret);
}

void Thread::mainResume ()
{
    if (!C_Thread::mainThread)
	return;

    C_Thread* currentThread = (C_Thread*) Thread::Self();

    mutex_unlock(C_Thread::mainThread->mx);
    cthread_yield();
    mutex_lock(currentThread->mx);	
}

#ifdef NO_INLINES
#  define CTHREAD_CC_
#  include <ClassLib/c_thread.n>
#  undef CTHREAD_CC_
#endif
