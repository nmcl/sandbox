/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: cpp_task.cc,v 1.19 1996/12/03 10:22:29 nmcl Exp $
 */

#ifndef CONFIGURE_H_
#  include <Config/Configure.h>
#endif

#include <unistd.h>
#include <iostream.h>

#ifndef CPP_TASK_H_
#  include <ClassLib/cpp_task.h>
#endif

static _semaphore globalSem;

long  CPP_Task::base_key = 0;
task* CPP_Task::_mainTask = (task*) 0;
long  CPP_Task::mainTaskID = 0;

// semaphore class definition

_semaphore::_semaphore () { sigs = 0; }

_semaphore::~_semaphore () {}

int _semaphore::pending () { return sigs <= 0; }

void _semaphore::signal ()
{
    if (sigs++ == 0) alert();
    if (sigs > 1) sigs = 1;
}

void _semaphore::wait ()
{
    for (;;)
    {
	if (--sigs >= 0) return;
	sigs++;
	thistask->sleep(this);
    }
}

/*
 * The real work.
 * The C++ task library does not allow the thread to return from the Basic_Task
 * constructor. If it does, the system will crash. So, users must prevent
 * this from happening.
 */

Basic_Task::Basic_Task (CPP_Task* toUse, long key, int stackSize)
		       : task((char*) key, DEFAULT_MODE, stackSize)
{
    sem.wait();

    toUse->Body();

    cancel(0);
}

Basic_Task::~Basic_Task () {}


CPP_Task::CPP_Task (const char*)
{
    thread_key = CPP_Task::base_key++;
    mainTaskID = thread_key;

#ifndef DELAY_TASK    
    _mainTask = object::this_task();
#endif    
}

CPP_Task::CPP_Task ()
{
    thread_key = CPP_Task::base_key++;
    my_block = new Basic_Task(this, thread_key);

#ifdef DELAY_TASK
    if (!_mainTask)
	_mainTask = object::this_task();
#endif
}

CPP_Task::CPP_Task (unsigned long stackSize)
{
    thread_key = CPP_Task::base_key++;
    my_block = new Basic_Task(this, thread_key, (int) stackSize);
}

CPP_Task::~CPP_Task ()
{
    terminateThread();
}

long CPP_Task::Current_Thread () const
{
    task* currTask = object::this_task();
    
    if (currTask == _mainTask)
	return mainTaskID;
    else
	return (long) currTask->t_name;
}

void CPP_Task::terminateThread ()
{
    if (my_block)
    {
	// must terminate this task before we can remove it

	Basic_Task* ptr = my_block;
	my_block = 0;

	ptr->cancel(0);
	delete ptr;
    }
}

void CPP_Task::Suspend ()
{
    if (thread_key == 0)
    {
	globalSem.wait();
	return;
    }

    if (object::this_task() == my_block)
	my_block->sem.wait();
}

void CPP_Task::Resume ()
{
    my_block->sem.signal();
}

ostream& CPP_Task::print (ostream& strm) const
{
    strm << "Thread type is C++ Task.\n";
    return Thread::print(strm);
}

//
// Getting the main thread into the thread list...
//

class CPP_Main_Task : public CPP_Task
{
public:
    CPP_Main_Task ();
    ~CPP_Main_Task ();

    void Body ();
};

CPP_Main_Task::CPP_Main_Task () : CPP_Task("main") {}

CPP_Main_Task::~CPP_Main_Task () {}

void CPP_Main_Task::Body () {}

void Thread::Initialize ()
{
    if (!_initialized)
    {
	_initialized = TRUE;
	new CPP_Main_Task;
    }
}

void Thread::Exit (int retValue)
{
    if (CPP_Task::_mainTask)
	CPP_Task::_mainTask->resultis(retValue);
    else
	object::this_task()->resultis(retValue);
}

void Thread::mainResume ()
{
    if (!CPP_Task::_mainTask)
	return;

    CPP_Task* currentTask = (CPP_Task*) Thread::Self();

    globalSem.signal();
    currentTask->my_block->sem.wait();
}

#ifdef NO_INLINES
#  define CPPTASK_CC_
#  include <ClassLib/cpp_task.n>
#  undef CPPTASK_CC_
#endif
