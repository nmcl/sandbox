/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */

#ifndef CONFIGURE_H_
#  include <Config/Configure.h>
#endif

#include <iostream.h>

#ifndef LWP_THREAD_H_
#  include <ClassLib/lwp_thread.h>
#endif

extern "C"
{
#include <lwp/lwpmachdep.h>

#ifdef BROKEN_LWP_H
    int pod_setmaxpri(int);
    int lwp_stkcswset(thread_t, caddr_t);
    int lwp_setstkcache(int, int);
    int lwp_create(thread_t*, void (*func)(LWP_Thread *),
		   int, int, stkalign_t*, int, caddr_t);
    int lwp_destroy(thread_t);
    int lwp_yield(thread_t);
    int lwp_suspend(thread_t);
    int lwp_resume(thread_t);
    int lwp_setpri(thread_t, int);
    int lwp_self(thread_t*);
    int lwp_ping(thread_t);
    int lwp_sleep(struct timeval*);
    void pod_exit(int);
#endif
}

//
// Class LWP_Thread
//

static const int MaxPriority = 10;

LWP_Thread::LWP_Thread ()
		       : stack(0)
{
    caddr_t p1 = (caddr_t) this;
    
#ifndef STATIC_STACK
    (void) lwp_create(&mid, LWP_Thread::Execute, MaxPriority,
		      LWPSUSPEND, lwp_newstk(), 1, p1);
#else
    stack = ::new stkalign_t[MINSTACKSZ];
    (void) lwp_create(&mid, LWP_Thread::Execute, MaxPriority,
		      LWPSUSPEND, STKTOP(&stack[MINSTACKSZ]), 1, p1);
#endif
    
    thread_key = mid.thread_key;
    (void) lwp_suspend(mid);
}

LWP_Thread::LWP_Thread (unsigned long stackSize)
{
    caddr_t p1 = (caddr_t) this;
    
    stack = ::new stkalign_t[stackSize];

    (void) lwp_create(&mid, LWP_Thread::Execute, MaxPriority,
		      LWPSUSPEND, STKTOP(&stack[stackSize]), 1, p1);
    thread_key = mid.thread_key;
    (void) lwp_suspend(mid);
}

// For creating the LWP_Thread for "main"

LWP_Thread::LWP_Thread (thread_t tid)
{
    thread_key = tid.thread_key;
    mid = tid;
}

// tidy things up before we terminate thread

LWP_Thread::~LWP_Thread ()
{
    terminateThread();
}

void LWP_Thread::terminateThread ()
{
    /*
     * Destruction of thread should release resources.
     */

    thread_t comp;

    (void) lwp_self(&comp);

    if (SAMETHREAD(comp, mid))
	stack = 0;
    else
    {
	if (stack)
	{
	    ::delete [] stack;
	    stack = 0;
	}
    }
    
    (void) lwp_destroy(mid);
}

long LWP_Thread::Current_Thread () const
{
    thread_t tid;

    (void) lwp_self(&tid);

    return tid.thread_key;
}

void LWP_Thread::Execute (LWP_Thread *p1)
{
    p1->Body();
    p1->terminateThread();
}

void LWP_Thread::Suspend ()
{
    (void) lwp_suspend(mid);
}

void LWP_Thread::Resume ()
{
    (void) lwp_resume(mid);
}

void LWP_Thread::Sleep (struct timeval* doze) { (void) lwp_sleep(doze); }

thread_t LWP_Thread::Thread_ID () const { return mid; }

ostream& LWP_Thread::print (ostream& strm) const
{
    strm << "Thread type is Sun's lwp.\n";
    return Thread::print(strm);
}

//
// Getting the main thread into the thread list...
//

class LWP_Main_Thread : public LWP_Thread
{
public:
    LWP_Main_Thread (thread_t);
    ~LWP_Main_Thread ();

    void Body ();

    static LWP_Main_Thread* mainThread;
};

LWP_Main_Thread* LWP_Main_Thread::mainThread = 0;


LWP_Main_Thread::LWP_Main_Thread (thread_t t) : LWP_Thread(t) {}

LWP_Main_Thread::~LWP_Main_Thread () {}

void LWP_Main_Thread::Body () {}

void Thread::Initialize ()
{
    if (!_initialized)
    {
	_initialized = TRUE;
	
	(void) pod_setmaxpri(MaxPriority+1);
    
#ifndef STATIC_STACK
	(void) lwp_setstkcache(2048, 10);
#endif    

	thread_t me;
	lwp_self(&me);
	(void) lwp_setpri(me, MaxPriority+1);
	LWP_Main_Thread::mainThread = new LWP_Main_Thread(me);
    }
}

void Thread::Exit (int retValue)
{
    pod_exit(retValue);
}

void Thread::mainResume ()
{
    LWP_Main_Thread::mainThread->Resume();
}

#ifdef NO_INLINES
#  define LWPTHREAD_CC_
#  include <ClassLib/lwp_thread.n>
#  undef LWPTHREAD_CC_
#endif
