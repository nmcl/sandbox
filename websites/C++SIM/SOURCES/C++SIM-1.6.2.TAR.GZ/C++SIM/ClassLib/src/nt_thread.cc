/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: nt_thread.cc,v 1.10 1996/04/12 15:04:16 nmcl Exp $
 */

#ifndef NT_CONFIGURE_H_
#  include <Config/NT_Configure.h>
#endif

#include <iostream.h>

#ifndef RESOURCE_H_
#  include <Common/Resource.h>
#endif

#ifndef ERROR_H_
#  include <Common/Error.h>
#endif

#ifndef NTTHREAD_H_
#  include <ClassLib/NT_Thread.h>
#endif

static const int MaxPriority = THREAD_PRIORITY_NORMAL;

NT_Thread* NT_Thread::mainThread = 0;


NT_Thread::NT_Thread (HANDLE)
		     : _prio(MaxPriority+1),
		       sem(CreateSemaphore(NULL, 0, 1, 0)),
		       dead(FALSE)
{
    mid = GetCurrentThreadId();
    thread_key = mid;
    NT_Thread::mainThread = this;
}

NT_Thread::NT_Thread ()
		     : _prio(MaxPriority),
		       sem(CreateSemaphore(NULL, 0, 1, 0)),
		       dead(FALSE)
{
    LPVOID p1 = (LPVOID) this;
    thrHandle = CreateThread(NULL, 0,
			     (LPTHREAD_START_ROUTINE) NT_Thread::Execute, p1,
			     0, &mid);
	
    SetThreadPriority(thrHandle, _prio);

    thread_key = (long) mid;
}

NT_Thread::NT_Thread (unsigned long stackSize)
		     : _prio(MaxPriority),
		       sem(CreateSemaphore(NULL, 0, 1, 0)),
		       dead(FALSE)
{
    LPVOID p1 = (LPVOID) this;
    thrHandle = CreateThread(NULL, stackSize,
			     (LPTHREAD_START_ROUTINE) NT_Thread::Execute, p1,
			     0, &mid);

    SetThreadPriority(thrHandle, _prio);
    thread_key = (long) mid;
}

// tidy things up before we terminate thread

NT_Thread::~NT_Thread ()
{
    terminateThread();
}

void NT_Thread::terminateThread ()
{
    /*
     * If one thread terminates another then we must switch contexts
     * to the terminating thread for it to tidy itself up. Then that
     * thread must switch back to us.
     */

    dead = TRUE;
    
    if (mid == GetCurrentThreadId())
    {
	ReleaseSemaphore(sem, 1, NULL);
	ExitThread(0);
    }
    else
    {
	NT_Thread::Resume();
	WaitForSingleObject(sem, INFINITE);
    }
}

long NT_Thread::Current_Thread () const
{
    return GetCurrentThreadId();
}

DWORD NT_Thread::Execute (LPDWORD p1)
{
    NT_Thread* _p1 = (NT_Thread*) p1;
    
    WaitForSingleObject(_p1->sem, INFINITE);

    if (!_p1->dead)
    {
	_p1->Body();
	_p1->dead = TRUE;
    }
    
    return 0;
}

void NT_Thread::Suspend ()
{
    NT_Thread* ptr = (NT_Thread*) Thread::Self();

    if ((ptr == NT_Thread::mainThread) && (ptr != this))
	return;

    if (ptr == this)
    {
	WaitForSingleObject(sem, INFINITE);
	if (dead)
	    terminateThread();
    }
}

void NT_Thread::Resume ()
{
    if (_prio <= MaxPriority)
	ReleaseSemaphore(sem, 1, NULL);
    else
    {
	NT_Thread* ptr = (NT_Thread*) Thread::Self();
	ReleaseSemaphore(sem, 1, NULL);
	WaitForSingleObject(ptr->sem, INFINITE);
	    
	if (dead)
	    terminateThread();
    }
}

ostream& NT_Thread::print (ostream& strm) const
{
    strm << "Thread type is NT threads.\n";
    return Thread::print(strm);
}

//
// Getting the main thread into the thread list...
//

class NT_Main_Thread : public NT_Thread
{
public:
    NT_Main_Thread (HANDLE);
    ~NT_Main_Thread ();

    void Body ();

    static NT_Main_Thread* mainThread;
};

NT_Main_Thread* NT_Main_Thread::mainThread = 0;


NT_Main_Thread::NT_Main_Thread (HANDLE m) : NT_Thread(m) {}

NT_Main_Thread::~NT_Main_Thread () {}

void NT_Main_Thread::Body () {}

void Thread::Initialize ()
{
    if (!_initialized)
    {
	_initialized = TRUE;
	HANDLE mainHandle = GetCurrentThread();
	SetThreadPriority(mainHandle, MaxPriority+1);
	NT_Main_Thread::mainThread = new NT_Main_Thread(mainHandle);
    }
}

void Thread::Exit (int retValue)
{
    exit(retValue);
}

void Thread::mainResume ()
{
    NT_Main_Thread::mainThread->Resume();
}

#ifdef NO_INLINES
#  define NTTHREAD_CC_
#  include <ClassLib/NT_Thread.n>
#  undef NTTHREAD_CC_
#endif
