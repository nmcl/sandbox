/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: posix_thread.cc,v 1.17 1996/12/03 10:22:30 nmcl Exp $
 */

#ifndef CONFIGURE_H_
#  include <Config/Configure.h>
#endif

#include <iostream.h>

#ifndef POSIX_THREAD_H_
#  include <ClassLib/posix_thread.h>
#endif

extern "C"
{
    void _exit(int);
}

//
// Class Posix_Thread
//


pthread_mutex_t globalMutex;
pthread_key_t _key;

static const int MaxPriority = 10;

long Posix_Thread::base_key = 0;


Posix_Thread::Posix_Thread ()
			   : dead(FALSE),
			     waitThread(0)
{
    any_t p1 = (any_t) this;

    (void) pthread_attr_init(&_attr);

#if defined(PTHREAD_DRAFT_8) || defined(PTHREAD_SOLARIS)
    sched_param param;
#ifdef PTHREAD_DRAFT_8    
    param.prio = MaxPriority;
#else
    param.sched_priority = MaxPriority;
#endif

    (void) pthread_attr_setschedparam(&_attr, &param);
    (void) pthread_attr_setdetachstate(&_attr, PTHREAD_CREATE_DETACHED);
#else
    int state = 1;
    
    (void) pthread_attr_setprio(&_attr, MaxPriority);
    (void) pthread_attr_setdetachstate(&_attr, &state);
#endif
    
    (void) pthread_create(&_thread, &_attr, Posix_Thread::Execute, p1);
    
    (void) pthread_mutex_init(&_lock, 0);
    (void) pthread_mutex_lock(&_lock);

    thread_key = base_key++;
}

Posix_Thread::Posix_Thread (unsigned long size)
			   : dead(FALSE),
			     waitThread(0)
{
    any_t p1 = (any_t) this;

    (void) pthread_attr_init(&_attr);

#if defined(PTHREAD_DRAFT_8) || defined(PTHREAD_SOLARIS)
    sched_param param;
#ifdef PTHREAD_DRAFT_8    
    param.prio = MaxPriority;
#else
    param.sched_priority = MaxPriority;
#endif    

    (void) pthread_attr_setschedparam(&_attr, &param);
    (void) pthread_attr_setdetachstate(&_attr, PTHREAD_CREATE_DETACHED);    
#else
    int state = 1;
    
    (void) pthread_attr_setprio(&_attr, MaxPriority);
    (void) pthread_attr_setdetachstate(&_attr, &state);    
#endif

    (void) pthread_attr_setstacksize(&_attr, (unsigned int) size);
    
    (void) pthread_create(&_thread, &_attr, Posix_Thread::Execute, p1);
    
    (void) pthread_mutex_init(&_lock, 0);
    (void) pthread_mutex_lock(&_lock);

    thread_key = base_key++;
}

// For creating the Posix_Thread for "main"

Posix_Thread::Posix_Thread (pthread_t me)
			   : dead(FALSE),
			     waitThread(0)			     
{
    thread_key = base_key++;

    (void) pthread_mutex_init(&globalMutex, 0);
    (void) pthread_mutex_lock(&globalMutex);
    (void) pthread_attr_init(&_attr);
    (void) pthread_setspecific(_key, (any_t) &thread_key);
    
#if defined(PTHREAD_DRAFT_8) || defined(PTHREAD_SOLARIS)
    sched_param param;
#ifdef PTHREAD_DRAFT_8    
    param.prio = MaxPriority+1;    
#else
    param.sched_priority = MaxPriority+1;
#endif    
    (void) pthread_setschedparam(me, 0, &param);
#else
    (void) pthread_getschedattr(me, &_attr);
    (void) pthread_attr_setprio(&_attr, MaxPriority+1);
    (void) pthread_setschedattr(me, _attr);
#endif
}

// tidy things up before we terminate thread

Posix_Thread::~Posix_Thread ()
{
    terminateThread();
}

void Posix_Thread::terminateThread ()
{
    /*
     * If one thread terminates another then we must switch contexts
     * to the terminating thread for it to tidy itself up. Then that
     * thread must switch back to us.
     */
    
    dead = TRUE;
    waitThread = pthread_self();
    if (pthread_equal(waitThread, _thread) == 0)
    {
	Posix_Thread::Resume();
	pthread_mutex_lock(&_lock);
	pthread_mutex_destroy(&_lock);
	pthread_attr_destroy(&_attr);
    }
    else
    {
	pthread_mutex_destroy(&_lock);
	pthread_attr_destroy(&_attr);	
	pthread_exit(0);
    }
}

long Posix_Thread::Current_Thread () const
{
#if defined(PTHREAD_DRAFT_8) || defined(PTHREAD_SOLARIS)
    return *(long*) pthread_getspecific(_key);
#else
    any_t p = (any_t) 0;
    
    (void) pthread_getspecific(_key, &p);
    return *(long*) p;
#endif
}

void* Posix_Thread::Execute (void *p1)
{
    Posix_Thread* _p1 = (Posix_Thread*) p1;

    if (_p1)
    {
	if (!_p1->dead)
	{
	    (void) pthread_setspecific(_key, (any_t) &_p1->thread_key);

#ifdef PTHREAD_DRAFT_8
	    sched_param param;

	    (void) pthread_attr_getschedparam(&_p1->_attr, &param);
#endif
	    (void) pthread_mutex_lock(&_p1->_lock);
    
	    _p1->Body();
	    _p1->terminateThread();
	}
	else
	    (void) pthread_mutex_unlock(&_p1->_lock);
    }
    
    return 0;
}

void Posix_Thread::Suspend ()
{
    if (thread_key == 0)
    {
	pthread_mutex_lock(&globalMutex);
	return;
    }
    
    if (pthread_equal(_thread, pthread_self()) == 0)
	return;

    pthread_mutex_lock(&_lock);
    
    if (dead)
    {
	pthread_mutex_unlock(&_lock);
	pthread_exit(0);
    }
}

void Posix_Thread::Resume ()
{
    pthread_mutex_unlock(&_lock);
}

ostream& Posix_Thread::print (ostream& strm) const
{
    strm << "Thread type is pthreads.\n";
    return Thread::print(strm);
}

//
// Getting the main thread into the thread list...
//

class Posix_Main_Thread : public Posix_Thread
{
public:
    Posix_Main_Thread (pthread_t);
    ~Posix_Main_Thread ();

    void Body ();

    static Posix_Main_Thread* mainThread;
};

Posix_Main_Thread* Posix_Main_Thread::mainThread = 0;


Posix_Main_Thread::Posix_Main_Thread (pthread_t me) : Posix_Thread(me) {}

Posix_Main_Thread::~Posix_Main_Thread () {}

void Posix_Main_Thread::Body () {}

void Thread::Initialize ()
{
    if (!_initialized)
    {
	_initialized = TRUE;
#ifndef PTHREAD_SOLARIS	
	pthread_init();  // isn't this part of the standard?
#endif	
	(void) pthread_key_create(&_key, 0);

	pthread_t me = pthread_self();
	Posix_Main_Thread::mainThread = new Posix_Main_Thread(me);
    }
}

void Thread::Exit (int retValue)
{
    _exit(retValue);
}

void Thread::mainResume ()
{
    pthread_mutex_unlock(&globalMutex);
}

#ifdef NO_INLINES
#  define POSIXTHREAD_CC_
#  include <ClassLib/posix_thread.n>
#  undef POSIXTHREAD_CC_
#endif
