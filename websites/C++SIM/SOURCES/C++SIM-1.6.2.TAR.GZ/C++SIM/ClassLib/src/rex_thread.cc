/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: rex_thread.cc,v 1.4 1996/12/09 10:09:58 nmcl Exp $
 */

#ifndef CONFIGURE_H_
#  include <Config/Configure.h>
#endif

#include <sys/types.h>
#include <stdlib.h>
#include <iostream.h>
#include <lwp.h>

#ifndef REX_THREAD_H_
#  include <ClassLib/rex_thread.h>
#endif

extern struct pcb* currp;

static const int MaxPriority = MAXTPRI-1;
static const int defaultStackSize = 2048;

long Rex_Thread::base_key = 0;
long Rex_Thread::mainThreadID = -1;
sem* Rex_Thread::mainThread = (sem*) 0;


Rex_Thread::Rex_Thread (struct pcb* me)
		       : to_wait(0),
			 my_block(me)
{
    thread_key = base_key++;
    mainThreadID = thread_key;
    setenvp(currp, 0);
}

Rex_Thread::Rex_Thread ()
		       : to_wait(creats(0))
{
    caddr_t p1 = (caddr_t) this;
    thread_key = base_key++;
    my_block = creatp(MaxPriority, Rex_Thread::Execute, defaultStackSize, 0, 0, p1);
}

Rex_Thread::Rex_Thread (unsigned long stackSize)
		       : to_wait(creats(0))
{
    caddr_t p1 = (caddr_t) this;
    thread_key = base_key++;
    my_block = creatp(MaxPriority, Rex_Thread::Execute, stackSize, 0, 0, p1);
}

Rex_Thread::~Rex_Thread ()
{
    if (to_wait)
    {
        signals(to_wait);
	delete to_wait;
    }

    terminateThread();
}

void Rex_Thread::terminateThread ()
{
    if (my_block)
    {
	destroyp(my_block);
	my_block = 0;
	if (thread_key == Current_Thread())
	    yieldp();	// yield control
    }
}

void Rex_Thread::Execute (int prio, char**, Rex_Thread* p1)
{
    waits(p1->to_wait);
    
    p1->Body();
    p1->terminateThread();
}

void Rex_Thread::Suspend ()
{
    if (thread_key != 0)
    {
	// if this is not my process then set semaphore only
	if (currp != my_block)
	{
	    to_wait->count = -1;
	    return;
	}

	// otherwise do suspend
	waits(to_wait);
    }
    else
    {
	Rex_Thread::mainThread = creats(0);
	waits(Rex_Thread::mainThread);
    }
}

void Rex_Thread::Resume ()
{
    signals(to_wait);
}

long Rex_Thread::Current_Thread () const
{
    Rex_Thread* myEnv = (Rex_Thread*) getenvp(0);

    if (myEnv == (Rex_Thread*) 0)
	return Rex_Thread::mainThreadID;  // must be main thread
    else
	return myEnv->thread_key;
}

ostream& Rex_Thread::print (ostream& strm) const
{
    strm << "Thread type is Rex.\n";
    return Thread::print(strm);
}

class Rex_Main_Thread : public Rex_Thread
{
public:
    Rex_Main_Thread (struct pcb*);
    ~Rex_Main_Thread ();
    
    void Body ();
};


Rex_Main_Thread::Rex_Main_Thread (struct pcb* me) : Rex_Thread(me) {}

Rex_Main_Thread::~Rex_Main_Thread () {}

void Rex_Main_Thread::Body () {}

void Thread::Initialize ()
{
    if (!_initialized)
    {
	_initialized = TRUE;
	struct pcb* me = initlp(MaxPriority+1);
	setenvp(me, NULL);
	new Rex_Main_Thread(me);
    }
}

void Thread::Exit (int retValue)
{
    exit(retValue);
}

void Thread::mainResume ()
{
    signals(Rex_Thread::mainThread);
    Rex_Thread::Self()->Suspend();
}

#ifdef NO_INLINES
#  define REXTHREAD_CC_
#  include <ClassLib/rex_thread.n>
#  undef REXTHREAD_CC_
#endif
