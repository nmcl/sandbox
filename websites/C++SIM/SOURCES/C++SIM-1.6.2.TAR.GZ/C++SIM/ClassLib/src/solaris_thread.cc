/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */

#ifndef CONFIGURE_H_
#  include <Config/Configure.h>
#endif

#include <iostream.h>
#include <unistd.h>

#if defined(DEBUG) && !defined(DEBUG_H_)
#  include <Common/Debug.h>
#endif

#ifndef ERROR_H_
#  include <Common/Error.h>
#endif

#ifndef SOLARIS_THREAD_H_
#  include <ClassLib/solaris_thread.h>
#endif

/*
 * These are the Sun C routines which give access to threads.
 */

extern "C"
{
    size_t thr_min_stack();
    int    thr_setprio(thread_t, int);
    int    thr_getprio(thread_t, int*);
    void   thr_exit(void*);
    int    thr_suspend(thread_t);
    int    thr_continue(thread_t);
}

static const int MaxPriority = 10;

Solaris_Thread::Solaris_Thread ()
                               : waitThread(0),
				 dead(FALSE)
{
#ifdef DEBUG
    debug_stream << FAC_THREAD << CONSTRUCTORS << VIS_PROTECTED << endl;
    debug_stream << "Solaris_Thread::Solaris_Thread ()" << endl;
#endif

    caddr_t p1 = (caddr_t) this;

    (void) thr_create(NULL, 0, Solaris_Thread::Execute, p1,
		      THR_DETACHED | THR_SUSPENDED, &mid);
    
    (void) thr_setprio(mid, MaxPriority);
    thread_key = mid;

#ifdef DEBUG
    debug_stream << FAC_THREAD << CONSTRUCTORS << VIS_PROTECTED << endl;
    debug_stream << "Solaris_Thread id: " << thread_key << endl;
#endif
}

Solaris_Thread::Solaris_Thread (unsigned long stackSize)
                               : waitThread(0),
				 dead(FALSE)
{
#ifdef DEBUG
    debug_stream << FAC_THREAD << CONSTRUCTORS << VIS_PROTECTED << endl;
    debug_stream << "Solaris_Thread::Solaris_Thread ( " << stackSize << " )"
		 << endl;
#endif

    caddr_t p1 = (caddr_t) this;
    size_t minStackSize = thr_min_stack();
    size_t sizeToUse = ((stackSize < minStackSize) ? minStackSize : (unsigned int) stackSize);

    if (stackSize < minStackSize)
	error_stream << WARNING << "Stack size " << stackSize << " is too small. Using "
		     << minStackSize << endl;

    (void) thr_create(NULL, sizeToUse, Solaris_Thread::Execute,
		      p1, THR_DETACHED | THR_SUSPENDED, &mid);

    (void) thr_setprio(mid, MaxPriority);
    thread_key = mid;

#ifdef DEBUG
    debug_stream << FAC_THREAD << CONSTRUCTORS << VIS_PROTECTED << endl;
    debug_stream << "Solaris_Thread id: " << thread_key << endl;
#endif
}

// For creating the Solaris_Thread for "main"

Solaris_Thread::Solaris_Thread (thread_t tid)
                               : waitThread(0),
				 dead(FALSE)
{
#ifdef DEBUG
    debug_stream << FAC_THREAD << CONSTRUCTORS << VIS_PROTECTED << endl;
    debug_stream << "Solaris_Thread::Solaris_Thread ( "
		 << tid << " )" << endl;
#endif

    thread_key = tid;
    mid = tid;

#ifdef DEBUG
    debug_stream << FAC_THREAD << CONSTRUCTORS << VIS_PROTECTED << endl;
    debug_stream << "Solaris_Thread id: " << thread_key << endl;
#endif    
}

// tidy things up before we terminate thread

Solaris_Thread::~Solaris_Thread ()
{
#ifdef DEBUG
    debug_stream << FAC_THREAD << DESTRUCTORS << VIS_PROTECTED << endl;
    debug_stream << "Solaris_Thread::~Solaris_Thread - id: "
		 << thread_key << endl;
#endif

    terminateThread();
}

void Solaris_Thread::terminateThread ()
{
    if (!dead)
    {
	dead = TRUE;
	waitThread = thr_self();
	if (waitThread != mid)
	{
	    if (thr_continue(mid) == 0)
		(void) thr_suspend(waitThread);
	}
	else
	    thr_exit(0);
    }
}

void* Solaris_Thread::Execute (void *p1)
{
#ifdef DEBUG
    debug_stream << FAC_THREAD << FUNCTIONS << VIS_PRIVATE << endl;
    debug_stream << "Solaris_Thread::Execute ( " << p1 << " )" << endl;
#endif

    Solaris_Thread* _p1 = (Solaris_Thread*) p1;

#ifdef DEBUG
    debug_stream << FAC_THREAD << FUNCTIONS << VIS_PRIVATE << endl;
    debug_stream << "Solaris_Thread::Execute - calling body for "
		 << p1 << endl;
#endif

    if (!_p1->dead)
	_p1->Body();
    else
    {
	if (_p1->waitThread != 0)
	    thr_continue(_p1->waitThread);
    }

#ifdef DEBUG
    debug_stream << FAC_THREAD << FUNCTIONS << VIS_PRIVATE << endl;
    debug_stream << "Solaris_Thread::Execute - returned from body of "
		 << p1 << " terminating" << endl;
#endif
    
#ifdef DEBUG
    debug_stream << FAC_THREAD << FUNCTIONS << VIS_PRIVATE << endl;
    debug_stream << "Solaris_Thread::Execute - thread terminating" << endl;
#endif
    
    return 0;
}

void Solaris_Thread::Suspend ()
{
#ifdef DEBUG
    debug_stream << FAC_THREAD << FUNCTIONS << VIS_PUBLIC << endl;
    debug_stream << "Solaris_Thread::Suspend - thread " << Current_Thread()
		 << " suspending " << mid << endl;
#endif
    
    (void) thr_suspend(mid);

    if (dead)
    {
	(void) thr_continue(waitThread);
	thr_exit(0);
    }
}

void Solaris_Thread::Resume ()
{
#ifdef DEBUG
    debug_stream << FAC_THREAD << FUNCTIONS << VIS_PUBLIC << endl;
    debug_stream << "Solaris_Thread::Resume - thread " << Current_Thread()
		 << " resuming " << mid << endl;
#endif

    (void) thr_continue(mid);
}

ostream& Solaris_Thread::print (ostream& strm) const
{
    strm << "Thread type is Solaris threads.\n";
    return Thread::print(strm);
}

//
// Getting the main thread into the thread list...
//

class Solaris_Main_Thread : public Solaris_Thread
{
public:
    Solaris_Main_Thread (thread_t);
    ~Solaris_Main_Thread ();

    void Body ();

    static Solaris_Main_Thread* mainThread;
};

Solaris_Main_Thread* Solaris_Main_Thread::mainThread = 0;


Solaris_Main_Thread::Solaris_Main_Thread (thread_t t) : Solaris_Thread(t)
{
}

Solaris_Main_Thread::~Solaris_Main_Thread () {}

void Solaris_Main_Thread::Body () {}

void Thread::Initialize ()
{
    if (!_initialized)
    {
	_initialized = TRUE;
	
	int prio = MaxPriority+1;

	thread_t me = thr_self();
	(void) thr_setprio(me, prio);

#ifdef DEBUG
	debug_stream << FAC_THREAD << FUNCTIONS << VIS_PUBLIC << endl;
	debug_stream << "Thread::Initialize - creating main solaris thread"
		     << endl;
#endif
    
	Solaris_Main_Thread::mainThread = new Solaris_Main_Thread(me);
    }
}

void Thread::Exit (int retValue)
{
#ifdef DEBUG
    debug_stream << FAC_THREAD << FUNCTIONS << VIS_PUBLIC << endl;
    debug_stream << "Thread::Exit ( " << retValue << " )" << endl;
#endif
    
    _exit(retValue);
}

void Thread::mainResume ()
{
#ifdef DEBUG
    debug_stream << FAC_THREAD << FUNCTIONS << VIS_PUBLIC << endl;
    debug_stream << "Thread::mainResume" << endl;
#endif
    
    Solaris_Main_Thread::mainThread->Resume();
}

#ifdef NO_INLINES
#  define SOLARISTHREAD_CC_
#  include <ClassLib/solaris_thread.n>
#  undef SOLARISTHREAD_CC_
#endif
