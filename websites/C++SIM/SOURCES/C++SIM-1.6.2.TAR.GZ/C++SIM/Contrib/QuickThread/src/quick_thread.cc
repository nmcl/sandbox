/*
 * Copyright 1996 Commonwealth Scientific and Industrial Research
 * Organisation, Australia
 * The Commonwealth Scientific and Industrial Research Organisation makes
 * no representation about the suitability of this software for any
 * purpose.  It is provided "as is" without express or implied warranty.
 * Available under the same conditions as the C++SIM public distribution.
 *
 * Parts of this file
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */

#ifndef CONFIGURE_H_
#  include <Config/Configure.h>
#endif

#include <iostream.h>

#ifndef QUICK_THREAD_H_
#  include <Contrib/QuickThread/quick_thread.h>
#endif

#ifdef USE_RZSTACKS
#ifndef RZSTACKS_H_
#  include <RZStacks.h>
#endif
#endif

#include <memory.h>

extern "C"
{
#include <qt.h>
}

//
// Class Quick_Thread
//

const int Quick_Thread::MaxPriority = QT_MAXPRIO;
int Quick_Thread::NextId = 1;
Quick_Thread::qtq Quick_Thread::threadQueues[QT_MAXPRIO+2];
Quick_Thread* Quick_Thread::currentThread = 0;

Quick_Thread::Quick_Thread ()
{
    // Default is a 12kB stack.

    ThreadCreate(12*1024);
}

Quick_Thread::Quick_Thread (unsigned long stackSize)
{
    ThreadCreate(stackSize);
}

// Create a thread from the given Quick_Thread thread handle/stack pointer
// Used to convert main()'s thread of control into a Thread.
// The qt_t* argument is present merely to differentiate this constructor,
// which should only be used by Quick_Main_Thread::Quick_Main_Thread from
// the other constructors. A sensible value will first be assigned to
// sp when control switches from the main thread to some other thread.

Quick_Thread::Quick_Thread (int pr, qt_t* /* dummy argument */)
{
    sp = 0;
    stack_alloc = stack = 0;
    thread_key = NextId++;
    prio = pr;
}

// Common code for thread creation.

void
Quick_Thread::ThreadCreate(unsigned long stackSize)
{
    // Create an aligned stack and an aligned stack pointer
#ifdef USE_RZSTACKS
    unsigned long size = ((stackSize + QT_STKALIGN-1) & ~(QT_STKALIGN-1));
    stack_alloc = (unsigned char*)RZStacks::new_stk(size);
    int offset = 0;
#else
    unsigned long size = ((stackSize + QT_STKALIGN-1) & ~(QT_STKALIGN-1))
    			+ QT_STKALIGN-1;
    stack_alloc = new unsigned char[size];
    int offset = (unsigned long)stack_alloc & (QT_STKALIGN-1);
#endif
    memset(stack_alloc, 0, size);
    stack = stack_alloc + offset;
    sp = QT_SP(stack, (size-offset-QT_STKALIGN) & ~(QT_STKALIGN-1));

    // Initialise the stack with the helper functions needed to
    // start things off, and their arguments.
    sp = QT_ARGS(sp, this, this, Execute, Only);

    // Set the thread's id and priority.
    thread_key = NextId++;
    prio = QT_MAXPRIO;
}

// tidy things up before we terminate thread

Quick_Thread::~Quick_Thread ()
{
    terminateThread();
}

// Only() is called out of QuickThreads to start the thread executing.
// It's passed a function to call (userf) and an argument to userf.
// The second argument is available as an argument for Only()'s use.
// This is all set up in the call of QT_ARGS() above.

void Quick_Thread::Only (void* u, void*, qt_userf_t *userf)
{
    userf(u);
    /* NOTREACHED */
}

// YeildHlp does bookkeeping for the context switch. It runs
// on the new processes's stack; when it returns, the new process
// is executing. It saves the old process's sp and sets currentThread.

void* Quick_Thread::YeildHlp (qt_t *sp, void* from, void* to)
{
    ((Quick_Thread*)from)->sp = sp;
    currentThread = ((Quick_Thread*)to);
    return 0;
}

// AbortHlp is called to clean up a process that's being killed
// off. t is the process being terminated, to is the next process to
// run. At this point it is assumed that there _is_ a process to run.
// This runs on to's stack, so it's safe to delete t's stack.

void* Quick_Thread::AbortHlp (qt_t *, void* t, void* to)
{
    Quick_Thread* thread = (Quick_Thread*)t;
    if(thread->stack_alloc)
#ifdef USE_RZSTACKS
	RZStacks::delete_stk(thread->stack_alloc);
#else
	::delete [] thread->stack_alloc;
#endif
    thread->stack_alloc = thread->stack = 0;
    thread->sp = 0;
    currentThread = ((Quick_Thread*)to);
    return 0;
}


// Return the first runnable process. The returned process
// is put back in the queue as the last process at that priority,
// for round-robin within a priority.

Quick_Thread* Quick_Thread::nextThread()
{
    for(qtq* qp = &threadQueues[QT_MAXPRIO+1];
			qp >= &threadQueues[0]; qp--) {
	if(qp->len > 0) {
	    Quick_Thread* th = *qp->head++;
	    if(qp->head >= &qp->q[QT_QLEN])
		qp->head = &qp->q[0];
	    qp->len--;
	    th->addThread();	// round-robin
	    // This is the one...
	    return th;
	}
    }
    // Nobody to run.
    return 0;
}

// Put a thread into its priority queue. Dies horribly if
// there's no room in the queue.

void Quick_Thread::addThread()
{
    qtq* qp = &threadQueues[prio];
    if(qp->len >= QT_QLEN) {
	cerr << "Queue overflow in Quick_Thread::addThread()\n";
	abort();
    }
    *qp->tail++ = this;
    if(qp->tail >= &qp->q[QT_QLEN])
	qp->tail = &qp->q[0];
    qp->len++;
}

// Remove a thread from its queue. Not an error if it's not in one.

void Quick_Thread::removeThread()
{
    qtq* qp = &threadQueues[prio];
    int l = qp->len;

    if(l <= 0) {
	// If the queue is empty...
	return;
    }

    Quick_Thread** tp = qp->head;

    if(*tp == this) {
	// If the element being removed is the head of the queue
	if(++qp->head >= &qp->q[QT_QLEN])
	    qp->head = &qp->q[0];
	qp->len--;
	return;
    }

    if(l <= 1) {
	// The queue had only one entry, but it wasn't the thread that
	// was dequeueing itself...
	return;
    }

    // Search for the entry in the queue, and copy
    // the queue elements up by one after the entry
    // has been found. NB: The loop doesn't examine the
    // last element of the queue! That's done after the loop.

    Quick_Thread** tpnxt = tp+1;
    if(tpnxt >= &qp->q[QT_QLEN])
	tpnxt = &qp->q[0];
    int found = 0;
    while(l > 1) {
	if(*tp == this) {
	    // This is the one
	    found = 1;
	}
	// If we've already found the element, copy the
	// remainder of the queue up one plece.
	if(found) *tp = *tpnxt;
	tp = tpnxt;
	tpnxt++;
	if(tpnxt>= &qp->q[QT_QLEN])
	    tpnxt = &qp->q[0];
	l--;
    }

    // If the element was found in the loop, or it was the last
    // in the queue, adjust the length and the position of the tail.

    if(found || *tp == this) {
	if(--qp->tail < &qp->q[0])
	    qp->tail = &qp->q[QT_QLEN-1];
	qp->len--;
    }
}

int
Quick_Thread::topPrio()
{
    for(qtq* qp = &threadQueues[QT_MAXPRIO+1];
			qp >= &threadQueues[0]; qp--) {
	if(qp->len > 0) {
	    return qp - &threadQueues[0];
	}
    }
    // Nobody to run.
    return -1;
}

// Kill off a thread.

void Quick_Thread::terminateThread ()
{
    sp = 0;
    removeThread();	// remove the thread from the queue if it's in one
    if(this == currentThread) {
	// If we're suiciding, get the next eligible thread,
	Quick_Thread *next = nextThread();
	if(next == 0) {
	    cerr << "No-one to run in terminateThread\n";
	    abort();
	}
	// kill off this one, and start the new thread.
	// AbortHlp has to clean up the stack and any other resources.
	QT_ABORT(AbortHlp, this, next, next->sp);
    } else {
	// If we're being murdered by another thread, we have to clean
	// up ourselves.
	if(stack_alloc)
#ifdef USE_RZSTACKS
	    RZStacks::delete_stk(stack_alloc);
#else
	    ::delete [] stack_alloc;
#endif
	stack_alloc = stack = 0;
	sp = 0;
    }
}

long Quick_Thread::Current_Quick_Thread ()
{
    return currentThread ? currentThread->thread_key : 0;
}

long Quick_Thread::Current_Thread () const
{
    return Current_Quick_Thread();
}

// Run the thread's Body() function as the process's code, and
// kill off the thread if Body() ever returns.

void Quick_Thread::Execute (void *t)
{
    Quick_Thread* thread = (Quick_Thread*)t;
    thread->Body();
    thread->terminateThread();
}


// Make the thread un-runnable. If it was the current thread,
// run the highest priority runnable thread.

void Quick_Thread::Suspend ()
{
    removeThread();
    if(this == currentThread) {
	Quick_Thread *next = nextThread();
	if(next == 0) {
	    cerr << "No-one to run in Suspend\n";
	    abort();
	}
	// It's not possible that this == next, because
	// removeThread() took this out of the queues before
	// nextThread() was called, so the QT_BLOCK is safe.
	QT_BLOCK(YeildHlp, this, next, next->sp);
    }
}

// Make the thread runnable. If there is now a higher-priority
// thread to run, run it, otherwise just return.

void Quick_Thread::Resume ()
{
    addThread();
    if(topPrio() > currentThread->prio) {
	Quick_Thread *next = nextThread();
	if(next == 0) {
	    cerr << "No-one to run in Resume\n";
	    abort();
	}
	if(next != currentThread)
	    QT_BLOCK(YeildHlp, currentThread, next, next->sp);
    }
}

ostream& Quick_Thread::print (ostream& strm) const
{
    strm << "Thread type is Quick Thread.\n";
    strm << "stack allocation: 0x" << hex << ((unsigned long)stack_alloc)
	<< " stack: 0x" << ((unsigned long)stack)
	<< " stack pointer: 0x" << ((unsigned long)sp) << dec
	<< " priority: " << prio;
    return Thread::print(strm);
}

//
// Getting the main thread into the thread list...
//

class Quick_Main_Thread : public Quick_Thread
{
public:
    Quick_Main_Thread ();
    ~Quick_Main_Thread ();

    void Body ();

    static Quick_Main_Thread* mainThread;
};

Quick_Main_Thread* Quick_Main_Thread::mainThread = 0;

Quick_Main_Thread::Quick_Main_Thread ()
              : Quick_Thread(QT_MAXPRIO+1, (qt_t*)0) {
}

Quick_Main_Thread::~Quick_Main_Thread () {}

void Quick_Main_Thread::Body () {}

void Quick_Thread::Initialize ()
{
    // Initialise the queues
    for(int i = QT_MAXPRIO+1; i >= 0; i--) {
	qtq* qtp = &threadQueues[i];
	qtp->len = 0;
	qtp->head = qtp->tail = &qtp->q[0];
    }

    // Create the thread for main, make it the current thread, and put
    // it in the queue.
    currentThread = Quick_Main_Thread::mainThread = new Quick_Main_Thread();
    currentThread->addThread();
}

void Thread::Initialize ()
{
    Quick_Thread::Initialize();
}

void Thread::Exit (int retValue)
{
    exit(retValue);
}

void Thread::mainResume ()
{
    Quick_Main_Thread::mainThread->Resume();
}

/* The rites of Purification of threads */

#ifdef HAVE_PURE_THREADS_H_
extern "C"
{
#include <pure_threads.h>
}

int pure_thread_switch_protocol = PURE_THREAD_PROTOCOL_NOTICE_STACK_CHANGE;

int pure_thread_init_protocol = PURE_THREAD_INIT_IMPLICIT;

unsigned int
pure_thread_id_size(void)
{
  return sizeof (long);
}

void
pure_thread_id(void* tid_p)
{
  *(long*)tid_p = Quick_Thread::Current_Quick_Thread();
}

int
pure_thread_id_equal(void* tid_p0, void* tid_p1)
{
  return *(long*)tid_p0 == *(long*)tid_p1;
}

#endif

#ifdef NO_INLINES
#  define QUICKTHREAD_CC_
#  include <quick_thread.n>
#  undef QUICKTHREAD_CC_
#endif
