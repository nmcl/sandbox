/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: Semaphore.cc,v 1.5 1996/12/09 10:10:02 nmcl Exp $ 
 */

#if defined(DEBUG) && !defined(DEBUG_H_)
#  include <Common/Debug.h>
#endif

#ifndef ENTITY_H_
#  include <Event/Entity.h>
#endif

#ifndef ERROR_H_
#  include <Common/Error.h>
#endif

#ifndef SEMAPHORE_H_
#  include <Event/Semaphore.h>
#endif

#ifndef ENTITILIST_H_
#  include <EntityList.h>
#endif

Semaphore::Semaphore ()
		     : numberWaiting(0),
		       numberOfResources(1),
		       currentResources(1)		       
{
#ifdef DEBUG
    debug_stream << CONSTRUCTORS << FAC_SEMAPHORE << VIS_PUBLIC;
    debug_stream << "Semaphore::Semaphore ()" << endl;
#endif    
}

Semaphore::Semaphore (long number)
		     : numberWaiting(0),
		       numberOfResources(number),
		       currentResources(number)
{
#ifdef DEBUG
    debug_stream << CONSTRUCTORS << FAC_SEMAPHORE << VIS_PUBLIC;
    debug_stream << "Semaphore::Semaphore ( " << number << " )" << endl;
#endif    
}

Semaphore::~Semaphore ()
{
#ifdef DEBUG
    debug_stream << DESTRUCTORS << FAC_SEMAPHORE << VIS_PUBLIC;
    debug_stream << "Semaphore::~Semaphore ()" << endl;
#endif
    
    if (numberWaiting != 0)
	error_stream << WARNING << "Semaphore being removed with clients waiting." << endl;
}

long Semaphore::NumberWaiting () const
{
    return numberWaiting;
}

Semaphore::Outcome Semaphore::Get (Entity* toWait)
{
    if (currentResources > 0)
	currentResources--;
    else
    {
	numberWaiting++;

        waitingList.insert(toWait);
	toWait->Cancel();
    }

    return Semaphore::DONE;
}

Semaphore::Outcome Semaphore::TryGet (Entity* toWait)
{
    if (currentResources == 0)
	return Semaphore::WOULD_BLOCK;
    else
	return Get(toWait);
}

Semaphore::Outcome Semaphore::Release ()
{
    if (numberWaiting > 0)
    {
	currentResources++;

	if (currentResources > numberOfResources)
	    currentResources = numberOfResources;
	
	numberWaiting--;

	// don't set trigger flag - not strictly a trigger

	waitingList.triggerFirst(FALSE);

	return Semaphore::DONE;
    }
    else
	return Semaphore::NOTDONE;
}
