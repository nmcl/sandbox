/*
 * Copyright (C) 1994, 1995, 1996, 1997
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: Job.h,v 1.1 1996/12/09 10:10:08 nmcl Exp $
 */

#ifndef JOB_H_
#define JOB_H_

class Job
{
public:
    Job ();
    ~Job ();
};

#endif
