/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: c_thread.h,v 1.4 1996/12/03 10:22:31 nmcl Exp $
 */

#ifndef C_THREAD_H_
#define C_THREAD_H_

extern "C"
{
#include <cthread.h>
}

#ifndef BOOLEAN_H_
#  include <Common/Boolean.h>
#endif

#ifndef THREAD_H_
#  include <ClassLib/thread.h>
#endif

class ostream;


/*
 * General notes: the C Threads library does not have any notion of priorities.
 */

/*
 * This is a threads interface to the C threads library.
 */

class C_Thread : public Thread
{
    friend void Thread::mainResume();
    
public:
    virtual void Suspend ();                // Suspend an active thread
    virtual void Resume ();                 // Resume a suspended thread

    // Body of "active" object (defined in the deriving class)    
    virtual void Body () = 0;
    
    virtual long Current_Thread () const;   // Returns current thread id

    virtual ostream& print (ostream&) const;
    
protected:
    C_Thread ();
    C_Thread (unsigned long stackSize);  // ignore stack size
    C_Thread (cthread_t);
    virtual ~C_Thread ();

    virtual void terminateThread ();
    
private:
    static void* Execute (void*); // This routine calls the 'main' object code

    cthread_t cid;
    mutex_t   mx;
    Boolean   dead;

    static long base_key;
    static C_Thread* mainThread;
    static long mainThreadID;
};

#include <ClassLib/c_thread.n>

#endif
