/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: cpp_task.h,v 1.9 1996/12/03 10:22:31 nmcl Exp $
 */

#ifndef CPP_TASK_H_
#define CPP_TASK_H_

#include <task.h>

#ifndef BOOLEAN_H_
#  include <Common/Boolean.h>
#endif

#ifndef THREAD_H_
#  include <ClassLib/thread.h>
#endif

class ostream;


/*
 * General notes: the C++ Task library does not have any notion of priorities,
 * and as such we need to simulate them (not too difficult).
 */

/*
 * A simple semaphore class based on the one in the Cfront 2.1 release notes.
 */

class _semaphore : public object
{
public:
    _semaphore ();
    ~_semaphore ();

    int pending ();
    void wait ();
    void signal ();

private:
    int sigs;	// the number of excess signals
};


/*
 * We do this because multiple (single) inheritence doesn't work
 * (setjmp/longjmp limitations).
 * Although multiple inheritence does, we should still support
 * older versions of C++, so ...
 */

class CPP_Task;

class Basic_Task : public task
{
public:
    Basic_Task (CPP_Task*, long, int = SIZE);
    virtual ~Basic_Task ();

    _semaphore sem;
};


/*
 * This is a threads interface to the C++ task library.
 */

class CPP_Task : public Thread
{
    friend Basic_Task;
    friend void Thread::Exit(int);
    friend void Thread::mainResume();

public:
    virtual void Suspend ();                // Suspend an active thread
    virtual void Resume ();                 // Resume a suspended thread

    // Body of "active" object (defined in the deriving class)    
    virtual void Body () = 0;
    
    virtual long Current_Thread () const;   // Returns current thread id

    virtual ostream& print (ostream&) const;
    
protected:
    CPP_Task ();
    CPP_Task (unsigned long stackSize);
    CPP_Task (const char*);
    virtual ~CPP_Task ();

    virtual void terminateThread ();
    
private:
    Basic_Task* my_block;

    static long base_key;
    static task* _mainTask;
    static long mainTaskID;
};

#include <ClassLib/cpp_task.n>

#endif
