/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */

#ifndef LWP_THREAD_H_
#define LWP_THREAD_H_

extern "C"
{
#include <lwp/lwp.h>
}

#ifndef BOOLEAN_H_
#  include <Common/Boolean.h>
#endif

#ifndef THREAD_H_
#  include "thread.h"
#endif

extern "C"
{
#include <lwp/stackdep.h>
}

class ostream;

/*
 * This is the Sun thread implementation of the Thread virtual class. It
 * provides an implementation for all of the pure virtual functions declared
 * in the Thread base class.
 *
 * Note: if any problems occur when using the Sun thread package, try
 * increasing the stack size and/or the number of stacks to create in
 * Initialize.
 */

class LWP_Thread : public Thread
{
public:
    virtual void Suspend ();                // Suspend an active thread
    virtual void Resume ();                 // Resume a suspended thread
    virtual void Sleep (struct timeval*);   // Put active thread to sleep for duration specified

    virtual void Body () = 0;               // Body of "active" object (defined in the deriving class)
    virtual long Current_Thread () const;   // Returns current thread id

    thread_t Thread_ID () const;            // Returns current thread's Sun thread_key

    virtual ostream& print (ostream&) const;

protected:
    LWP_Thread ();
    LWP_Thread (unsigned long stackSize);
    LWP_Thread (thread_t);      // Create thread with given thread_key
    virtual ~LWP_Thread ();

    virtual void terminateThread ();
    
private:
    // This routine calls the 'main' object code    
    static void Execute (LWP_Thread*);
    
    stkalign_t* stack;

    thread_t mid;
};

#include <ClassLib/lwp_thread.n>

#endif
