/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: nt_thread.h,v 1.9 1996/12/03 10:22:31 nmcl Exp $
 */

#ifndef NT_THREAD_H_
#define NT_THREAD_H_

#include <stdlib.h>
#include <sys/types.h>
#include <windows.h>
#include <process.h>

#ifndef BOOLEAN_H_
#  include <Common/Boolean.h>
#endif

#ifndef THREAD_H_
#  include "thread.h"
#endif

#ifndef thread_t
#define thread_t long
#endif

class ostream;

class NT_Thread : public Thread
{
public:
    virtual void Suspend ();                // Suspend an active thread
    virtual void Resume ();                 // Resume a suspended thread

    // Body of "active" object (defined in the deriving class)    
    virtual void Body () = 0;
    
    virtual long Current_Thread () const;   // Returns current thread id

    virtual ostream& print (ostream&) const;

protected:
    NT_Thread ();
    NT_Thread (unsigned long stackSize);
    NT_Thread (HANDLE);                     // create with given thread handle
    virtual ~NT_Thread ();

    virtual void terminateThread ();
    
private:
    // This routine calls the 'main' object code    
    static DWORD Execute (LPDWORD);

    int _prio;
    HANDLE sem, thrHandle;
    unsigned long mid;
    Boolean dead;

    static NT_Thread* mainThread;
};

extern ostream& operator<< (ostream& strm, const NT_Thread& nt);

#include <ClassLib/NT_Thread.n>

#endif
