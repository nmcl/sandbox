/*
 * Copyright (C) 1994, 1995, 1996, 1997
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: posix_thread.h,v 1.8 1996/12/09 10:10:12 nmcl Exp $
 */

#ifndef POSIX_THREAD_H_
#define POSIX_THREAD_H_

extern "C"
{
#include <pthread/pthread.h>
}

#ifndef BOOLEAN_H_
#  include <Common/Boolean.h>
#endif

#ifndef THREAD_H_
#  include "thread.h"
#endif

class ostream;

#define any_t void*

/*
 * This is the Posix thread implementation of the Thread virtual class.
 */

class Posix_Thread : public Thread
{
public:
    virtual void Suspend ();                // Suspend an active thread
    virtual void Resume ();                 // Resume a suspended thread

    // Body of "active" object (defined in the deriving class)    
    virtual void Body () = 0;
    
    virtual long Current_Thread () const;   // Returns current thread id

    virtual ostream& print (ostream&) const;

protected:
    Posix_Thread ();
    Posix_Thread (unsigned long stackSize);
    Posix_Thread (pthread_t);
    virtual ~Posix_Thread ();

    virtual void terminateThread ();
    
private:
    // This routine calls the 'main' object code    
    static void* Execute (void*);

    Boolean dead;
    pthread_t _thread, waitThread;
    pthread_mutex_t _lock;
    pthread_attr_t _attr;

    static long base_key;
};

#include <ClassLib/posix_thread.n>

#endif
