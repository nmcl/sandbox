/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: rex_thread.h,v 1.2 1996/12/03 10:22:32 nmcl Exp $
 */

#ifndef REX_THREAD_H_
#define REX_THREAD_H_

#ifndef CONFIGURE_H_
#  include <Config/Configure.h>
#endif

#ifndef BOOLEAN_H_
#  include <Common/Boolean.h>
#endif

#ifndef THREAD_H_
#  include <ClassLib/thread.h>
#endif

class ostream;

class Rex_Thread : public Thread
{
    friend void Thread::mainResume();
    friend void Thread::Initialize();
    
public:
    virtual void Suspend ();                // Suspend an active thread
    virtual void Resume ();                 // Resume a suspended thread

    // Body of "active" object (defined in the deriving class)    
    virtual void Body () = 0;
    
    virtual long Current_Thread () const;   // Returns current thread id

    virtual ostream& print (ostream&) const;

protected:
    Rex_Thread ();
    Rex_Thread (unsigned long stackSize);
    Rex_Thread (struct pcb*);
    virtual ~Rex_Thread ();

    virtual void terminateThread ();
    
private:
    // This routine calls the 'main' object code    
    static void Execute (int, char**, Rex_Thread*);

    struct sem* to_wait;
    struct pcb* my_block;

    static long base_key;
    static struct sem* mainThread;
    static long mainThreadID;
};

#include <ClassLib/rex_thread.n>

#endif
