/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */

#ifndef SOLARIS_THREAD_H_
#define SOLARIS_THREAD_H_

#include <thread.h>

#ifndef BOOLEAN_H_
#  include <Common/Boolean.h>
#endif

#ifndef THREAD_H_
#  include "thread.h"
#endif

class ostream;

/*
 * This is the Sun Solaris thread implementation of the Thread virtual class.
 */

class Solaris_Thread : public Thread
{
public:
    virtual void Suspend ();                // Suspend an active thread
    virtual void Resume ();                 // Resume a suspended thread

    // Body of "active" object (defined in the deriving class)    
    virtual void Body () = 0;
    virtual long Current_Thread () const;   // Returns current thread id

    virtual ostream& print (ostream&) const;

protected:
    Solaris_Thread ();
    Solaris_Thread (unsigned long stackSize);
    Solaris_Thread (thread_t);     // Create thread with given Sun thread_key
    virtual ~Solaris_Thread ();

    virtual void terminateThread ();
    
private:
    static void* Execute (void*); // This routine calls the 'main' object code

    thread_t mid, waitThread;
    Boolean dead;
};

#include <ClassLib/solaris_thread.n>

#endif
