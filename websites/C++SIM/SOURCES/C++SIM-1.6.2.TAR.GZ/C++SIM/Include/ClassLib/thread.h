/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: thread.h,v 1.12 1996/12/09 10:10:13 nmcl Exp $ 
 */

#ifndef THREAD_H_
#define THREAD_H_

#ifndef RESOURCE_H_
#  include <Common/Resource.h>
#endif

/*
 * This class defines a template for threads packages which will be used to
 * provide "active" objects in C++. Such objects are not derived from this
 * class, but instead a thread implementation class is derived from this.
 * That class will then define the pure virtual functions, and "active" objects
 * are then derived from that class.
 * Because not every thread package provides an easy way of identifying and
 * locating threads, the Thread class does provide such a scheme through the
 * use of the Identify and Self operations. A linked list of threads is formed
 * and added to whenever a new thread is created.
 */

class ostream;


class Thread : public Resource
{
public:
    virtual void Suspend () = 0; // How to suspend a thread
    virtual void Resume () = 0;  // How to resume a suspended thread
    virtual void Body () = 0;    // The 'main' part of the code

    // Should return some unique thread identity key    
    virtual long Current_Thread () const = 0;

    virtual long Identity () const; // Returns the identify of this thread

    static Thread *Self ();         // Returns the current thread

    // Exit program
    static void Exit (int = 0);

    // Need routine to explicitly resume main.
    static void mainResume ();
    
    // Initialize must be called exactly once at the start of the program    
    static void Initialize ();
    
    virtual ostream& print (ostream&) const;
    static  ostream& printAll (ostream&);

protected:
    Thread ();
    virtual ~Thread ();

    virtual void terminateThread () = 0; // terminate and release resources
    
    long thread_key;    // key which must be set in derived class.

private:
    void Insert (Thread*, Thread*);
    void Remove (Thread*);
    
    Thread *next, *prev;
    
    static Thread *_head;
    static Boolean _initialized;
};

#include <ClassLib/thread.n>

#endif
