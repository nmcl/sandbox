/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: thread_type.h,v 1.7 1996/12/20 15:29:51 nmcl Exp $ 
 */

#ifndef THREAD_TYPE_H_
#define THREAD_TYPE_H_

#ifdef REX_THREAD
#  ifndef REX_THREAD_H_
#    include <ClassLib/rex_thread.h>
#  endif
#endif

#ifdef LWP_THREAD
#  ifndef LWP_THREAD_H_
#      include <ClassLib/lwp_thread.h>
#  endif
#endif

#ifdef CPP_TASK
#  ifndef CPP_TASK_H_
#      include <ClassLib/cpp_task.h>
#  endif
#endif

#ifdef SOLARIS_THREAD
#  ifndef SOLARIS_THREAD_H_
#    include <ClassLib/solaris_thread.h>
#  endif
#endif

#ifdef POSIX_THREAD
#  ifndef POSIX_THREAD_H_
#    include <ClassLib/posix_thread.h>
#  endif
#endif

#ifdef NT_THREAD
#  ifndef NT_THREAD_H_
#    include <ClassLib/nt_thread.h>
#  endif
#endif

#ifdef C_THREAD
#  ifndef C_THREAD_H_
#    include <ClassLib/c_thread.h>
#  endif
#endif

#ifdef QUICK_THREAD
#  ifndef QUICK_THREAD_H_
#    include <Contrib/QuickThread/quick_thread.h>
#  endif
#endif

#endif
