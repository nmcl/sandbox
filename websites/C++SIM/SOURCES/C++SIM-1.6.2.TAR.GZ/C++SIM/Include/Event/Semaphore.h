/*
 * Copyright (C) 1994, 1995, 1996, 1997
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: Semaphore.h,v 1.3 1996/12/09 10:10:15 nmcl Exp $ 
 */

#ifndef SEMAPHORE_H_
#define SEMAPHORE_H_

#ifndef BOOLEAN_H_
#  include <Common/Boolean.h>
#endif

#ifndef TRIGGERQUEUE_H_
#  include <Event/TriggerQueue.h>
#endif

class Entity;
class EntityList;

class Semaphore
{
public:
    enum Outcome { DONE, NOTDONE, WOULD_BLOCK };
	
    Semaphore ();
    Semaphore (long number); // number of resources available
    virtual ~Semaphore ();

    virtual Semaphore::Outcome Get (Entity*);
    virtual Semaphore::Outcome Release ();
    
    /*
     * Try to get the semaphore, but return if this would block
     * the caller.
     */
    
    virtual Semaphore::Outcome TryGet (Entity*);

    long NumberWaiting () const;

private:
    TriggerQueue waitingList;
    long numberWaiting;
    long numberOfResources;
    long currentResources;
};

#endif
