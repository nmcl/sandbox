/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: Tester.cc,v 1.2 1996/04/09 10:53:06 nmcl Exp $
 */

#include <iostream.h>

#ifndef RESOURCE_H_
#  include <Common/Resource.h>
#endif

#ifndef TESTER_H_
#  include "Tester.h"
#endif

#ifndef DUMMYPROCESS_H_
#  include "DummyProcess.h"
#endif

long numberOfJobs = 0;

Tester::Tester (long processes, long iter)
               : number(processes),
		 iterations(iter),
		 dataStream(0.1, 10000.0),
                 head(0)
{
}

Tester::~Tester ()
{
    if (head)
	delete head;
}

void Tester::Body ()
{
    for (int i = 0; i < number; i++)
    {
	DummyProcess *dp = new DummyProcess(dataStream());
	dp->next = head;
	head = dp;

	dp->ActivateAt(dataStream());
    }

    Scheduler::scheduler().Resume();

    while (numberOfJobs < iterations)
	Hold(10000);

    Scheduler::scheduler().Suspend();
    
    Thread::mainResume();
}

void Tester::Await ()
{
    Resume();
    Thread::Self()->Suspend();
}

void Tester::Exit ()
{
    Thread::Exit();
}

