/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: Tester.h,v 1.1 1996/03/19 12:03:25 nmcl Exp $
 */

#ifndef TESTER_H_
#define TESTER_H_

#ifndef PROCESS_H_
#  include <ClassLib/Process.h>
#endif

#ifndef RANDOM_H_
#  include <ClassLib/Random.h>
#endif

class DummyProcess;

class Tester : public Process
{
public:
    Tester (long, long);
    ~Tester ();

    void Body ();

    void Await ();
    void Exit ();

private:
    long number, iterations;
    UniformStream dataStream;

    DummyProcess*  head;
};

#endif
